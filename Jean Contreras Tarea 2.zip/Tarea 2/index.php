<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css"  href="index.css"> <!-- enlace al css -->
	<title>Ventas</title>
</head>
<body>
	<?php 
		session_start(); // inicio de la sesion
		if (!isset($_SESSION['persona'])){ //si no existe el array persona lo creo
			$_SESSION['persona']= array();
		}
		if (isset($_POST['insertar'])){  //inserto los valores de persona
			$nom = $_POST['NOM'];
			$COD = $_POST['COD'];
			$MIN = $_POST['MIN'];
			$FOR = $_POST['FOR'];

			$error=0;   //para encontrar errores
			for ($i = 0; $i<strlen($nom); $i++){  //recorro la escritura del nombre ingresado
				if(ord($nom[$i])<65 or ord($nom[$i])>122){ //si una letra del string nombre ingresado no es una letra
					echo "Nombre solo de letras        ";  //muestro el error
					echo "<br>";
					$error=1;  //marco la existencia de un error
					break; //termino el ciclo for
				}
			}
			for ($i = 0; $i<strlen($COD); $i++){ //recorro la escritura del valor en COD ingresado
				if(ord($COD[$i])<48 or ord($COD[$i])>57 and $error == 0){ //si no esta compuesto por numeros enteros positivos
					echo "Ingrese solo numeros enteros positivos en las ventas";
					echo "<br>";
					$error=1; //marco la existencia de un error
					break; //termino el ciclo for
				}
			}
			for ($i = 0; $i<strlen($MIN); $i++){ //recorro la escritura del valor en MIN ingresado
				if(ord($MIN[$i])<48 or ord($MIN[$i])>57 and $error == 0){ //si no esta compuesto por numeros enteros positivos
					echo "Ingrese solo numeros enteros positivos en las ventas";
					echo "<br>";
					$error=1; //marco la existencia de un error
					break; //termino el ciclo for
				}
			}
			for ($i = 0; $i<strlen($FOR); $i++){ //recorro la escritura del valor en FOR ingresado
				if(ord($FOR[$i])<48 or ord($FOR[$i])>57 and $error == 0){ //si no esta compuesto por numeros enteros positivos
					echo "Ingrese solo numeros enteros positivos en las ventas";
					echo "<br>";
					$error=1; //marco la existencia de un error
					break; //termino el ciclo for
				}
			}

			if (empty($nom)||empty($COD)||empty($MIN)||empty($FOR)||$error == 1){ // si los campos estan vacios o existe un error
				if($error !=1){
					echo "Rellena todos los valores"; //si solamente los campos estan vacios muestro por pantalla
				}
			}else { //si no existen errores y no hay campos vacios
				$persona = array(  // inicializo los datos del array persona
					"Nombre" => $nom,
					"COD" => $COD,
					"MIN" => $MIN,
					"FOR" => $FOR,
					"VentasTotal" => $Ventas = (($COD*34500)+($MIN*8800)+($FOR*58200)),
					"ComisionCOD"=> $ComiCOD = ($COD*34500)*0.06,
					"ComisionMIN"=> $ComiMIN = ($MIN*8800)*0.04,
					"ComisionFOR"=> $ComiFOR = ($FOR*58200)*0.09,
					"TotalComision"=> $TotalComi = ((($COD*34500)*0.06)+(($MIN*8800)*0.04)+(($FOR*58200)*0.09)),
				); 
				if (isset($_SESSION['persona'][$nom])){ // si el nombre de la persona ya existia le modifico los datos
					echo "Se ha modificado la Persona con el nombre: ".$nom;
				}else{ // si no existia, lo registro
					echo "Se ha registrado la persona";
				}		
				$_SESSION['persona'][$nom]=$persona;
			}
			
		}else if (isset($_POST['vaciar'])){ //para eliminar personas
			if (!isset($_POST['noms'])){ //si no se selecciona nadie
				echo "No hay Personas seleccionadas";

			}else{	//si se selecciona alguna persona
				$noms=$_POST['noms'];
				print_r($noms);

				foreach ($_SESSION['persona'] as $key =>$value){ //lo elimino
					if (in_array($key,$noms)){
						unset($_SESSION['persona'][$key]);
					}
				}
			echo "Persona(s) Borradas";
			}
		}

	?>
	<div class="imagenes"> <!-- las imagenes de la portada superior con sus valores-->
		<div class="juegos">
            <table class="table-responsive">
                <tr>
                <td><img src="cod.jpg"></td>
                <td><img src="for.jpg"></a></td>
                <td><img src="min.jpg"></a></td>
                </tr>
                <tr>
                <td>$34.500</td>
                <td>$58.200</td>
                <td>$8.800</td>
                </tr>
            </table>
        </div>
	<br>
	<br>
		
	</div>
	<div class="met-post"> 


	<form method="post"> <!-- creo el formulario mostrado por pantalla de los datos a ingresar -->

		<label for="NOM">Nombre vendedor</label>
		<input type="text" id="NOM" name="NOM" />
		<br>
		<label for="COD">Cantidad de ventas COD</label>
		<input type="text" id="COD" name="COD" />
		<br>
		<label for="MIN">Cantidad de ventas MIN</label>
		<input type="text" id="MIN" name="MIN" />
		<br>
		<label for="FOR">Cantidad de ventas FOR</label>
		<input type="text" id="FOR" name="FOR" />
		<br>
		<button type="submit" name="insertar">Insertar</button> <!-- los botones en pantalla -->
		<button type="submit" name="mostrar">Mostrar</button>
		<button type="submit" name="vaciar">Vaciar</button>
		<button type="submit" name="MEJOR">Mejor Vendedor</button>

		</div>
	
	<div class="tabla"> <!-- la tabla que se muestra por pantalla al precionar el boton mostrar -->

	

		<center>
	<?php
		if (isset($_POST['mostrar'])){ //boton mostrar
			if (count($_SESSION['persona'])===0){
				echo "<p> No hay Personas </p>";
			}else {  //tabla de registrados
				echo "<table border=10>";
				echo "<tr>";
				echo "<th></th>";
				echo "<strong><th>NOMBRE</th></strong>";
				echo "<th>Ventas COD</th>";
				echo "<th>Ventas MIN</th>";
				echo "<th>Ventas FOR</th>";
				echo "<th>Total Ventas</th>";
				echo "<th>Comision COD</th>";
				echo "<th>Comision MIN</th>";
				echo "<th>Comision FOR</th>";
				echo "<th>Total Comision</th>";
				echo "<th>Imagen del juego</th>";
				echo "<tr>";

				foreach ($_SESSION['persona'] as $key => $value){  //valores mostrados en la tabla que se encuentran registrados
					?>
					<tr>
						<td><input type="checkbox" name="noms[]" value="<?php echo $key; ?>"> </td>
						<td><?php echo $value['Nombre']; ?></td>
						<td><?php echo $value['COD']; ?></td>
						<td><?php echo $value['MIN']; ?></td>
						<td><?php echo $value['FOR']; ?></td>
						<td><?php echo "$",$value['VentasTotal']; ?></td>
						<td><?php echo "$",$value['ComisionCOD']; ?></td>
						<td><?php echo "$",$value['ComisionMIN']; ?></td>
						<td><?php echo "$",$value['ComisionFOR']; ?></td>
						<td><?php echo "$",$value['TotalComision']; ?></td>
						<td><?php if(($value['COD'] > $value['MIN'])and($value['COD'] > $value['FOR'])){ // calculo de la imagen que se mostrara dependiendo de las ventas
                            print "<img src=\"cod.jfif\">";
                        }else if(($value['MIN'] > $value['COD'])and($value['MIN'] > $value['FOR'])){
							print "<img src=\"min.jpg\">";
						}else{
							print "<img src=\"for.jfif\">";
						}
						?></td>

					</tr>
					<?php 
				}
				echo "</table>";
			} 
		}
		else if (isset($_POST['MEJOR'])){ //boton para la persona que mas ha tenido comisiones
			if (count($_SESSION['persona'])===0){
                echo "<p> No hay Personas </p>";
            }else{
			echo "<table border=3>";
            echo "<tr>";
			echo "<th>NOMBRE</th>";
			echo "<th>Total Comision</th>";
			echo "<tr>";


			$flag=0;
			$nombrecu;


			foreach($_SESSION['persona'] as $key => $value){ //calculo para la persona que mas ha tenido comisiones
				if($value['TotalComision']>$flag){
						$flag=$value['TotalComision'];
						$nombrecu= $value['Nombre'];

					}
					
			}
			?>
			<tr>
			<td><?php echo $nombrecu; ?></td>  <!-- se muestra por pantalla la persona con mas comisiones -->
				<td><?php echo $flag; ?></td>
			</tr>
			<?php
			}
            
			

        }

	?>
	

			</div>	
	</form>
	</center>
	
</body>
</html>