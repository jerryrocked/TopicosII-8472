<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>www.XYZ.com</title>
    <link rel="stylesheet" href="index.css">
</head>
<body>
    <header id="titulo">
        <section class="textos">
        <h1>XYZ</h1>
        <h2>Continua desperdiciando tu vida jugando</h2>
    </section>
        <div class="wave" 
        style="height: 150px; overflow: hidden;" ><svg viewBox="0 0 500 150" preserveAspectRatio="none" 
        style="height: 100%; width: 100%;"><path d="M0.00,49.98 C149.99,150.00 349.20,-49.98 500.00,49.98 L500.00,150.00 L0.00,150.00 Z" 
        style="stroke: none; fill: #5759e0;"></path></svg></div>
    </header>
    <section class="container">
        <article class="post">
            <h2>Call of Duty</h2>
            <img src="img/imagen1.jpg" width="400">
            <p>Call of Duty es una serie de videojuegos de disparos en primera persona, 
                de estilo bélico, desarrollada principal e inicialmente por Infinity Ward, 
                Treyarch, Sledgehammer Games y en menor proporción Raven Software y distribuida 
                por Activision.</p>
        </article>
        <article class="post">
        <h2>Minecraft</h2>
        <img src="img/imagen2.jpeg" width="400">
        <p>Minecraft es un videojuego de construcción de tipo mundo abierto o 
            sandbox creado originalmente por el sueco Markus Persson, y 
            posteriormente desarrollado por Mojang Studios.</p>
    </article>
    <article class="post">
    <h2>Fortnite</h2>
    <img src="img/imagen3.jpg" width="400">
    <p>Fortnite es un videojuego del año 2017 desarrollado por la 
        empresa Epic Games, lanzado como diferentes paquetes de 
        software que presentan diferentes modos de juego, pero que 
        comparten el mismo motor de juego y mecánicas</p>
    </article>
    <article class="post">
        <h2>Vendedores</h2>
        <img src="img/imagen4.jpg" width="400">
        <p>Ingresa el nombre del vendedor e ingresa cuanto a vendido</p>
        </article>
    </section>

  <!-- Aqui comienza la programacion php-->
    <?php 
    /*Inicio de sesion*/
    session_start();
    if (!isset($_SESSION['persona'])){
      $_SESSION['persona']=array();
    }
    /*creacion de variables*/
    if (isset($_POST['insertar'])){
      $Nom  = $_POST['Nom'];
      $Vcod = $_POST['Vcod'];
      $Vmin = $_POST['Vmin'];
      $Vfor = $_POST['Vfor'];
      if (empty($Nom)||empty($Vcod)||empty($Vmin)||empty($Vfor)){
        echo "Rellena todos los Valores";
      }else{
        $persona = array(
          "Nom"  => $Nom,
          "Vcod" => $Vcod,
          "Vmin" => $Vmin,
          "Vfor" => $Vfor,
        );
      }
    }
        if(isset($_SESSION['persona'][$Nom])){
          echo "Se ha modificado la Persona con el Nombre: ". $Nom;
        }else{
          echo "Se ha registrado el Vendedor";
        }
        $_SESSION['persona'][$Nom]=$persona;
        print_r($SESSION['persona']);
      
?>
    <form method="post" class="type">
      <br>Nombre
      <input type="text" id="Nom" name="Nom">
      <br>Cantidad Ventas COD 
      <input type="number" id="Vcod" name="Vcod">
      <br>Cantidad Ventas Minecraft
      <input type="number" id="Vmin" name="Vmin">
      <br>Cantidad Ventas Fortnite 
      <input type="number" id="Vfor" name="Vfor">
      <br>
      
      <button type="submit" name="insertar">insertar</button>
      
      <?php
      /*Funcion para hacer el calculo*/
        function ObtenerComision($Cantidad, $Porcentaje){
          $comision = ($Cantidad * $Porcentaje)/ 100;
          return $comision;
        }


        if(isset($_POST['mostrar'])){
          if (count($_SESSION['persona']===0)){
            echo "<p>No hay Personas </p>";
          }}else{
            echo "<table border=1 >";
            echo "<tr>";
            echo "<th></th>";
            echo "<th>Nombre</th>";
            echo "<th>Cantidad Ventas COD</th>";
            echo "<th>Cantidad Ventas Minecraft</th>";
            echo "<th>Cantidad Ventas Fortnite</th>";
            echo "<th>Total Ventas</th>";
            echo "<th>Comision Call of Duty</th>";
            echo "<th>Comision Minecraft</th>";
            echo "<th>Comision Fortnite</th>";
            echo "<th>Comision Total</th>";
            echo "</tr>";
            foreach ($_SESSION['persona'] as $key => $value){
              ?>
              
              <tr>
                <td input type="checkbox" name="Noms[]" value="<?php echo $kay?>"></td>
              <td><?php echo $value['Nom']?></td>
              <td><?php echo $value['Vcod']?></td>
              <td><?php echo $value['Vmin']?></td>
              <td><?php echo $value['Vfor']?></td>
              <td><?php echo $value['Vcod'] + $value['Vmin'] + $value['Vfor']?></td>
              <td><?php echo "$",ObtenerComision($value['Vcod'] *34500, 6)?></td>
              <td><?php echo "$",ObtenerComision($value['Vmin'] * 8800, 4)?> </td>
              <td><?php echo "$",ObtenerComision($value['Vfor'] *58200, 9)?></td>
              <td><?php echo "$",ObtenerComision($value['Vfor'] *58200, 9)+ObtenerComision($value['Vmin'] * 8800, 4)
              +ObtenerComision($value['Vcod'] *34500, 6)?></td>
              </tr>
              <?php
            }
            echo "</table>";
          }
        /*fin de php*/
      ?>
      </body>
    <footer>
        <section>
            <a href="#titulo">Volver al Inicio </a>
            <a href="mailto:v.cortsramrez@uadnresbello.edu">Contactanos</a>
        </section>
        <p>copyright 2022</p>
    </footer>