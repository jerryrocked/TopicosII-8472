<?php session_start(); ?>
<html>
<head>
	<meta charset="utf-8">
	<link href="css/estilo_2.css" rel="stylesheet" type="text/css">
	<title>Sales XYZ </title>
</head>
<body>
    <div class="container"> 
  <!-- Navigation -->
  <header> <a href="">
    <h4 class="logo">XYZ</h4>
    </a>
    <nav>
      <ul>
        <li><a href="xyzlanding.html">lANDING PAGE</a></li>
      </ul>
    </nav>
  </header>
	<?php 
		if (!isset($_SESSION['vendedor'])){
			$_SESSION['vendedor']= array();
		}

		if (isset($_POST['insertar'])){
			$nom_v = $_POST['nombre'];
			$v_cod = $_POST['cod'];
			$v_mine = $_POST['mine'];
			$v_fort = $_POST['fort'];

            //Validacion de Datos 
			 if (empty($nom_v)||empty($v_cod)||empty($v_mine)||empty($v_fort)){
			 	echo "Rellena todos los valores";
             }elseif(ctype_alpha($nom_v)==FALSE){
                 echo "solo ingrese letras";
             }elseif(ctype_digit($v_cod)==FALSE){
                 echo "Solo Ingrese Numeros! cod";
             }elseif(ctype_digit($v_mine)==FALSE){
                 echo "Solo Ingrese Numeros! mine";
             }elseif(ctype_digit($v_fort)==FALSE){
                 echo "Solo Ingrese Numeros! fort";
             }elseif($v_cod < 0 ){
                 echo "Solo Numeros Positivos! COD";
             }elseif($v_mine < 0 ){
                 echo "Solo Numeros Positivos! MINE";
             }elseif($v_fort < 0 ){
                 echo "Solo Numeros Positivos! FORT";
             }
                
            //Creacion de array con variables
             else {
            $dinero_ventas_cod = $v_cod * 34500;
            $dinero_ventas_mine = $v_mine * 8800;
            $dinero_ventas_fort = $v_fort * 58200;
    
            $total_ventas =$dinero_ventas_cod+$dinero_ventas_mine+$dinero_ventas_fort;
        
            $comision_vendedor_cod = $dinero_ventas_cod * 0.06;
            $comision_vendedor_mine = $dinero_ventas_mine * 0.04;
            $comision_vendedor_fort= $dinero_ventas_fort * 0.09;       
    
            $total_comision=$comision_vendedor_cod+$comision_vendedor_mine+$comision_vendedor_fort;
			$vendedor = array(
				"nombre" => $nom_v,
                "cod" => $v_cod,
                "mine" => $v_mine,
                "fort" => $v_fort,
                "total_ventas" =>$total_ventas ,
                "comision_cod" => $comision_vendedor_cod, 
                "comision_mine" =>$comision_vendedor_mine, 
                "comision_fort" => $comision_vendedor_fort,
                "total_comision" => $total_comision,
				); 
            
				if (isset($_SESSION['vendedor'][$nom_v])){
					echo "Se ha modificado la Persona con el RUT: ".$nom_v;
				}else{
					echo "Se han registrado las ventas del vendedor";
				}		
				$_SESSION['vendedor'][$nom_v]=$vendedor;
				//print_r($_SESSION['vendedor']);	
			}
        }

	?>

    
	<form method="post">
        <div class="recu" >
        <br>
		<br>NOMBRE VENDEDOR</br>
		<input type="text" id="reus" name="nombre" />
		<br>
		<br>VENTAS COD</br>
		<input type="text" id="reus" name="cod" />
		<br>
		<br>VENTAS MINE</br>
		<input type="text" id="reus" name="mine" />
		<br>
        <br>VENTAS FORT</br>
		<input type="text" id="reus" name="fort" />
		<br>
		<button type="submit" name="insertar">Insertar</button>
        <button type="submit" name="mostrar_v">Mostrar Vendedores </button>
        <button type="submit" name="m_m_comision">Vendedor Mayor Comision</button>
        </div>
	

	<?php

		if (isset($_POST['mostrar_v'])){
			if (!count($_SESSION['vendedor'])===0){
				echo "<p> No hay ventas </p>";
                
            //GENERAR TABLAS   
			}else {
                echo"<div style=overflow-x:auto;>";
				echo "<table width=100% border=1 cellspacing=0 cellpadding=6>";
				echo "<tr>";
				echo "<th>VENDEDOR</th>";
				echo "<th>V.COD</th>";
				echo "<th>V.MINE</th>";
                echo "<th>V.FORT</th>";
                echo "<th>TOTAL VENTAS</th>";
                echo "<th>COMISION COD</th>";
                echo "<th>COMISION MINE</th>";
                echo "<th>COMISION FORT</th>";
                echo "<th>TOTAL COMISION</th>";
                echo "<th>IMAGEN JUEGO MAS VENDIDO</th>";
				echo "<tr>";

            foreach ($_SESSION['vendedor'] as $key => $value){
        ?>     
                <tr>
                    <td> <?php echo $value['nombre']; ?> </td>
                    <td> <?php echo $value['cod']; ?> </td>
                    <td> <?php echo $value['mine']; ?> </td>
                    <td> <?php echo $value['fort']; ?> </td>
                    <td> <?php echo $value['total_ventas']; ?> </td>
                    <td> <?php echo $value['comision_cod']; ?> </td>
                    <td> <?php echo $value['comision_mine']; ?> </td>
                    <td> <?php echo $value['comision_fort']; ?> </td>
                    <td> <?php echo $value['total_comision']; ?> </td>
                    <td> <?php if($value['comision_cod'] > $value['comision_mine'] && $value['comision_cod'] > $value['comision_fort']){ ?>  <img src="/images/cod_2.jpg" class="fotos"/><br>Precio: 34500 <?php echo"<br>";echo"Ventas:",$value['cod']*34500;echo "<br>";echo "Comsion: ",$value['comision_cod']; }elseif($value['comision_mine'] > $value['comision_cod'] && $value['comision_mine'] > $value['comision_fort']){ ?> <img src="/images/mine_2.jpg" class="fotos"/><br>Precio: 8800  <?php "<br>";echo"Ventas:",$value['mine']*8800;echo "<br>";echo "Comision: ",$value['comision_mine'];  }else{?> <img src="/images/fort_2.jpg"  class="fotos"/> <br>Precio: 58200 <?php echo "<br>";echo"Ventas:",$value['fort']*58200;echo "<br>";echo "Comision: ",$value['comision_fort']; } ?> </td>
                    
                </tr>
                <?php 
            }
        echo "</table>";
			} 
		}

	?>
            
	<?php

		if (isset($_POST['m_m_comision'])){
			if (!count($_SESSION['vendedor'])===0){
				echo "<p> No hay ventas </p>";
                
            //GENERAR TABLAS   
			}else {
                echo"<div style=overflow-x:auto;>";
				echo "<table width=100% border=1 cellspacing=0 cellpadding=6>";
				echo "<tr>";
				echo "<th>VENDEDOR</th>";
				echo "<th>V.COD</th>";
				echo "<th>V.MINE</th>";
                echo "<th>V.FORT</th>";
                echo "<th>TOTAL VENTAS</th>";
                echo "<th>COMISION COD</th>";
                echo "<th>COMISION MINE</th>";
                echo "<th>COMISION FORT</th>";
                echo "<th>TOTAL COMISION</th>";
                echo "<th>IMAGEN JUEGO MAS VENDIDO</th>";
				echo "<tr>";

            $max_comision=0;
            foreach ($_SESSION['vendedor'] as $key => $value){
                $into_num=intval($value['total_comision']);
                if($into_num > $max_comision){
                    $max_comision=$into_num;
                    $mejor_vendedor=$value;
                }
            }
        ?>
                <tr>
                    <td><b> <?php echo $mejor_vendedor['nombre']; ?> </td>
                    <td><b> <?php echo $mejor_vendedor['cod']; ?> </td>
                    <td><b> <?php echo $mejor_vendedor['mine']; ?> </td>
                    <td><b> <?php echo $mejor_vendedor['fort']; ?> </td>
                    <td><b> <?php echo $mejor_vendedor['total_ventas']; ?> </td>
                    <td><b> <?php echo $mejor_vendedor['comision_cod']; ?> </td>
                    <td><b> <?php echo $mejor_vendedor['comision_mine']; ?> </td>
                    <td><b> <?php echo $mejor_vendedor['comision_fort']; ?> </td>
                    <td><b> <?php echo $mejor_vendedor['total_comision']; ?> </td>
                    <td> <?php if($value['comision_cod'] > $value['comision_mine'] && $value['comision_cod'] > $value['comision_fort']){ ?>  <img src="/images/cod_2.jpg" class="fotos"/><br><strong>Precio: 34500 <?php "<br>";echo"Ventas:",$mejor_vendedor['cod']*34500;echo "<br>";echo "Comsion: ",$mejor_vendedor['comision_cod']; }elseif($value['comision_mine'] > $value['comision_cod'] && $value['comision_mine'] > $value['comision_fort']){ ?> <img src="/images/mine_2.jpg" class="fotos"/><br><strong>Precio: 8800  <?php "<br>";echo"Ventas:",$mejor_vendedor['mine']*8800;echo "<br>";echo "Comision: ",$mejor_vendedor['comision_mine'];  }else{?> <img src="/images/fort_2.jpg"  class="fotos"/> <br><strong>Precio: 58200 <?php echo "<br>";echo"Ventas:",$mejor_vendedor['fort']*58200;echo "<br>";echo "Comision: ",$mejor_vendedor['comision_fort']; } ?> </td>
                </tr>
                <?php 
            
        echo "</table>";
			} 
		}

	?>
	</form>

  <!-- Copyrights Section -->

</div>
                        
<div class="copyright">&copy;2022- <strong>xyz games</strong></div>
</body>
</html>