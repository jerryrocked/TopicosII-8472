<!DOCTYPE html> 
<html>
	<head>
		<title>Empresa XYZ</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">
	<link rel="stylesheet" href="css/style.css" />
	</head>
    <body style="background-image: url(img/bgpattern-04.gif);"></body>
    <div class="header">
        <a href="#default" class="logo">EMPRESA XYZ</a>
        <div class="header-right">
          <a class="active" href="#home">Home</a>
          <a href="#contact">Contact</a>
          <a href="#about">About</a>
        </div>
      </div>
      <div class="tabs">
        <input type="radio" name="tabs" id="tabone" checked="checked">
        <label for="tabone">Call of Duty®: Vanguard</label>
        <div class="tab">
            <h1>Call of Duty®: Vanguard</h1>
            <hr/>
            <h3>Álzate en todos los frentes en la más reciente entrega de la aclamada saga Call of Duty. </h3>
            <br/>
            <img src="img/Call_of_Duty_Vanguard_cover_art.jpg" width="200" style="float: left; margin-right: 10px;"/>
            <p>Rebélate en cada frente: combate sobre el Pacífico, defiende Stalingrado con la precisión de un francotirador, lánzate desde el aire en Francia o atraviesa fuerzas en el norte de África. La franquicia de Call of Duty® regresa con Call of Duty®: Vanguard, donde los jugadores se sumergirán en el combate visceral de escala global de la Segunda Guerra Mundial.</p>

            <p>A través de una fascinante Campaña un grupo selecto de soldados de diferentes países se rebelará contra la amenaza más grande del mundo. Los jugadores también dejarán su huella en el Multijugador característico de Call of Duty® y en la nueva y emocionante experiencia Zombis.</p>
                
            <p>Call of Duty®: Vanguard también marcará el comienzo de una nueva integración sin igual de Call of Duty®: Warzone™ tras el lanzamiento, y contará con progreso cruzado y juego multigeneración. Además, también contará con un calendario lleno de contenido gratuito tras el lanzamiento que añadirá nuevos mapas Multijugador, modos, eventos de temporada y de la comunidad y más.</p>
            <div class="hs-responsive-embed-youtube"><iframe src="https://www.youtube.com/embed/h5ZmjeMpOiQ" frameborder="0" allowfullscreen=""></iframe></div>
            <br>
            <br> 
            <p>Precio $ 34500</p>    
        </div>
        
        <input type="radio" name="tabs" id="tabtwo">
        <label for="tabtwo">FORTNITE</label>
        <div class="tab">
            <h1>FORTNITE</h1>
            <hr/>
            <h3>CAPÍTULO 3 - TEMPORADA 2 DE FORTNITE: RESISTENCIA </h3>
            <br/>
            <img src="img/fortnite-battle-royale-4k-iphone-13-pro.jpg" width="200" style="float: left; margin-right: 10px;"/>
            <p>¡ÚNETE A LA RESISTENCIA EN LA BATALLA FINAL PARA LIBERAR EL PUNTO CERO! PRUEBA LAS NUEVAS TÁCTICAS, COMO ESPRINTAR, TREPAR Y MUCHO MÁS. SUBE A BORDO DEL AUTOBÚS DE BATALLA ACORAZADO PARA REALIZAR UNA POTENTE INCURSIÓN O INCORPORA EL DEFLECTOR A TU CAMIÓN PARA EMBESTIR A LO GRANDE. ¡ACABA CON TUS OPONENTES EN EL COMBATE DEFINITIVO POR EL PUNTO CERO DEL CAPÍTULO 3 - TEMPORADA 2: RESISTENCIA</p>

            <p>¡LA FINANCIACIÓN CON BARRAS ESTÁ DE VUELTA! DONA TUS BARRAS PARA DOTAR DE ARMAS Y VEHÍCULOS A LA RESISTENCIA. Y LLEVA LAS COSAS AL SIGUIENTE NIVEL FINANCIANDO LA INSTALACIÓN DE TORRETAS, COMO LA "TORRETA PESADA", PERFECTA PARA FRENAR EL AVANCE DE LOS VEHÍCULOS.</p>
                
            <p>CONTROLA UN TANQUE TITÁN DE LA OI Y UTILIZA SU CAÑÓN PARA DERRIBAR LOS OBSTÁCULOS. PARA DUPLICAR LA OFENSIVA, UN COMPAÑERO PUEDE COLOCARSE A LOS MANDOS DE LA TORRETA DE ARTILLERÍA. GRACIAS A LA FINANCIACIÓN CON BARRAS, PODRÁS CONSTRUIR EL MONSTRUO METÁLICO DEFINITIVO: EL AUTOBÚS DE BATALLA ACORAZADO. COMPLETA EL DISEÑO CON NEUMÁTICOS BESTIALES TODOTERRENO, UN DEFLECTOR Y DOS TIPOS DE TORRETAS. ¡DONA TUS BARRAS PARA TRAER ESTOS AUTOBUSES A LA ISLA!</p>
            <div class="hs-responsive-embed-youtube"><iframe src="https://www.youtube.com/embed/BIFM5e4OFfI" frameborder="0" allowfullscreen=""></iframe></div>
            <br>
            <br> 
            <p>Precio $ 58200</p>  
        </div>
        
        <input type="radio" name="tabs" id="tabthree">
        <label for="tabthree">MINECRAFT</label>
        <div class="tab">
            <h1>MINECRAFT</h1>
            <hr/>
            <h3>EL MUNDO ES TUYO </h3>
            <br/>
            <img src="img/Minecraft-xbox-one.webp" width="200" style="float: left; margin-right: 10px;"/>
            <p>Prepárate para una aventura de posibilidades ilimitadas mientras construyes, extraes, combates criaturas y exploras el cambiante paisaje de Minecraft.</p>

            <p>Combate criaturas, construye refugios y explora el paisaje: es el trabajo de un día cuando intentas sobrevivir y prosperar en modo de supervivencia.</p>
                
            <p>¡Construye, busca y diviértete con otros! El mundo de Minecraft es aún mejor cuando lo exploras con tus mejores amigos.</p>
            <br>
            <br> 
            <div class="hs-responsive-embed-youtube"><iframe src="https://www.youtube.com/embed/vdrn4ouZRvQ" frameborder="0" allowfullscreen=""></iframe></div>
            <br>
            <br> 
            <p>Precio $ 8800</p>  
        </div>
        
        
        
        <input type="radio" name="tabs" id="tabfour">
        <label for="tabfour">VENTAS</label>
        <div class="tab">
          <h1>Sistema de Ventas</h1>
          <hr/>
          <br/>
          <a href="../test/sales.php">
            <img src="img/341-3418895_boton-entrar-png-traffic-sign-transparent-png.png" width="100" style="float: left; margin-right: 10px;"/>
        </div>
      </div>
</html>