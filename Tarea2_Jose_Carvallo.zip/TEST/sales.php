<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	
	<title>Formularios</title>
</head>

<body style="background-color: antiquewhite;">
	
    
	<?php 
		session_start();
		if (!isset($_SESSION['persona'])){
			$_SESSION['persona']= array();
		}
		if (isset($_POST['insertar'])){
			$rut = $_POST['RUT'];
			$nom = $_POST['NOM'];
			$ape = $_POST['APE'];
			$cod = $_POST['COD'];
			$mine = $_POST['MINE'];
			$fort = $_POST['FORT'];
			if (empty($rut)||empty($nom)||empty($ape)||empty($cod)||empty($mine)||empty($fort)){
				echo "Rellena todos los valores";
			}else {
				$persona = array(
					"rut" => $rut,
					"Nombre" => $nom,
					"Apellido" => $ape,
					"COD" => $cod,
					"MINE" => $mine,
					"FORT" => $fort,
				); 
				if (isset($_SESSION['persona'][$rut])){
					echo "Se ha modificado la Persona con el RUT: ".$rut;
				}else{
					echo "Se ha registrado la persona";
				}		
				$_SESSION['persona'][$rut]=$persona;
				print_r($_SESSION['persona']);	
			}
			
		}else if (isset($_POST['vaciar'])){
			if (!isset($_POST['ruts'])){
				echo "No hay Personas seleccionadas";

			}else{	
				$ruts=$_POST['ruts'];
				print_r($ruts);

				foreach ($_SESSION['persona'] as $key =>$value){
					if (in_array($key,$ruts)){
						unset($_SESSION['persona'][$key]);
					}
				}
			echo "Persona(s) Borradas";
			}
		}

	?>
	<form method="post">
		<a><label for="RUT">RUT</label>
		<input type="number" placeholder="SOLO NUMEROS" id="RUT" name="RUT" />
	</a>
		<a><label for="NOM">NOMBRE</label>
		<input type="text" pattern="[A-Za-z]*" placeholder="SOLO LETRAS" id="NOM" name="NOM" />
	</a>
	<a>
		<label for="APE">APELLIDO</label>
		<input type="text" pattern="[A-Za-z]*" placeholder="SOLO LETRAS" id="APE" name="APE" />
	</a>
	<br>
	<a>
		<label for="COD">Cantidad de ventas Call Of Duty</label>
		<input type="number" placeholder="SOLO NUMEROS" id="COD" name="COD" />
	</a>
	<a>
		<label for="MINE">Cantidad de ventas Minecraft</label>
		<input type="number" placeholder="SOLO NUMEROS" id="MINE" name="MINE" />
	</a>
	<a>
		<label for="FORT">Cantidad de ventas Fortnite</label>
		<input type="number" placeholder="SOLO NUMEROS" id="FORT" name="FORT" />
	</a>
	<br>
		<button type="submit" name="insertar">Insertar</button>
		<button type="submit" name="mostrar">Mostrar</button>
		<button type="submit" name="vaciar">Vaciar</button>
		<input type="button" onclick="window.location.href = 'http://localhost/test/';" value="Volver"/>
		

	<?php
	
	$TEST= array(
			"rut" => NULL,
			"Nombre" => NULL,
			"Apellido" =>NULL,
			"TOT" => NULL,
		);
		if (isset($_POST['mostrar'])){
			if (count($_SESSION['persona'])===0){
				echo "<p> No hay Personas </p>";
			}else {
				echo "<table border=1>";
				echo "<tr>";
				echo "<th></th>";
				echo "<th>RUT</th>";
				echo "<th>NOMBRE</th>";
				echo "<th>APELLIDO</th>";
				echo "<th><p>Ventas COD</p>
				<p> Precio  $34500 </p>
				<img src='img/communityIcon_m4hjnmn9nuw71.png' width='60'/>
				</th>";
				echo "<th><p>Ventas Minecraft</p>
				<p> Precio  $8800 </p>
				<img src='img/minecraft_logo_icon_168974.webp' width='60'/>	
				</th>";
				echo "<th><p>Ventas Fortnite</p>
				<p> Precio  $58200 </p>
				<img src='img/275c8b2e8734e0ae3e0d4f6f662aa00f.png' width='60'/>
				</th>";
				echo "<th>Ventas Totales en $</th>";
				echo "<th>Comision Call of Duty (%6)</th>";
				echo "<th>Comision Fortnite (%9)</th>";
				echo "<th>Comision Minecraft (%4)</th>";
				echo "<th>Comisiones Totales en $</th>";
				echo "<tr>";



				foreach ($_SESSION['persona'] as $key => $value){
					?>
					<tr>
						<td><input type="checkbox" name="ruts[]" value="<?php echo $key; ?>"> </td>
						<td><?php echo $value['rut']; ?></td>
						<td><?php echo $value['Nombre']; ?></td>
						<td><?php echo $value['Apellido']; ?></td>
						<td><?php echo $value['COD']; ?></td>
						<td><?php echo $value['MINE']; ?></td>
						<td><?php echo $value['FORT']; ?></td>
						<td><?php echo ($value['FORT']*58200 + $value['COD']*34500 + $value['MINE']*8800); ?></td>
						<td><?php echo (($value['COD']*(34500*0.06))); ?></td>
						<td><?php echo (($value['FORT']*(58200*0.09))); ?></td>
						<td><?php echo (($value['MINE']*(8800*0.04))); ?></td>
						<?php $value['TOT']=(($value['FORT']*(58200*0.09)) + ($value['COD']*(34500*0.06)) + ($value['MINE']*(8800*0.04))); ?>
						<td><?php echo $value['TOT']; ?></td>
						<?php
						if ($value['TOT']> $TEST['TOT']) {
							$TEST['Nombre'] = $value['Nombre'];
							$TEST['Apellido'] = $value['Apellido'];
							$TEST['Rut'] = $value['rut'];
							$TEST['TOT'] = $value['TOT'];
						}
						?>

						




					</tr>
					<?php 
				}
				echo "</table>";
			} 
			echo '<span style="color:RED;text-align:center;">El Vendedor con mayor comision es </span>'. $TEST['Nombre'].' '.$TEST['Apellido']. '<span style="color:RED;text-align:center;"> con un monto de </span> $'.$TEST['TOT'];
		}

	?>
	
	</form>
</body>
</html>