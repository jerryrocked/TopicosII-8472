<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width">
    <title>Juegos</title>
    <link rel="stylesheet" href="css/Estilo.css">
</head>

<body>
    <header>
       <h1 width="150" align="center" background_color="black"> <font size="24" color="green">Mejores Juegos XYZ</font></h1>
    </header>
    <section class="juegos">
          <div class="Minecraft" id="Minecraft">
            <div class="icono">
            <p ><img src="pics/Minecraft.jpg" width="300" height="200"></p>
            <h3 align = "center"><font size="10" color="white"><a href="https://www.minecraft.net/es-es">Minecraft</a></font></h3>
            <div class="parrafo">
            <p >Minecraft es un videojuego de construcción de tipo «mundo abierto» o sandbox creado originalmente por el sueco Markus Persson 
                (conocido comúnmente como «Notch»)
                ,18​ y posteriormente desarrollado por Mojang Studios (actualmente parte de Microsoft).</p>
            </div></div></div>
          
        
          <div class="Fortnite" id="Fortnite">
            <div class="icono">
            <p ><img src="pics/fornite.jpg" width="300" height="200"></p>
            <h3 align = "center"><font size="10" color="white"><a href="https://www.epicgames.com/fortnite/es-ES/home">Fortnite</a></font></h3>
            <div class="parrafo">
            <p >Fortnite es un videojuego del año 2017 desarrollado por la empresa Epic Games, 
                lanzado como diferentes paquetes de software que presentan diferentes modos de juego,
                pero que comparten el mismo motor de juego y mecánicas.</p>
            </div>
            </div></div>
    
          <div class="COD" id="COD">
            <div class="icono">
            <p ><img src="pics/cod.jpg" width="300" height="200"></p>
            <h3 align = "center"><font size="10" color="white"><a href="https://www.callofduty.com/es">COD</a></font></h3>
            <div class="parrafo">
            <p >Call Of Duty es una serie de videojuegos de disparos en primera persona, de estilo bélico, 
                desarrollada principal e inicialmente por Infinity Ward, 
                Treyarch, Sledgehammer Games y en menor proporción Raven Software y distribuida por Activision</p>
            </div>
            </div>
            </div>
        </section>
        <section class="ventas">
            <h1 width="150" align="center" ><a href="http://localhost/Tarea/index1.php">ventas</a> </h1>
        </section>
        <footer>
            <div class="paginas">
                <li><a href="https://www.callofduty.com/es">Call of Duty</a> </li>
                <li><a href="https://www.minecraft.net/es-es">Minecraft</a></li>
                <li><a href="https://www.epicgames.com/fortnite/es-ES/home">Fortnite</a> </li>
            </div>
            
        </footer>
                    
        </body>
        </html>
