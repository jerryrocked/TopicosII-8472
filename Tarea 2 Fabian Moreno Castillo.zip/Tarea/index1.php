<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" href="css/Estilo2.css">
	<title>Formularios</title>
</head>
<body>
	<?php 
    # Se inicia el arreglo persona
		session_start();
		if (!isset($_SESSION['persona'])){
			$_SESSION['persona']= array();
		}
		if (isset($_POST['insertar'])){
			$Vendedor = $_POST['vend'];
            $Ventas_cod = $_POST['cod'];
            $Ventas_fortnite = $_POST['fort'];
            $Ventas_mogroft = $_POST['mine'];
            
			if (empty($Vendedor)||empty($Ventas_cod)||
            empty($Ventas_fortnite)||
            empty($Ventas_mogroft)){
				echo "Rellena todos los valores";
			}else {
                #se agrega las variables al arreglo
				$persona = array(
                    "vend" => $Vendedor,
                    "cod" => $Ventas_cod,
                    "fort" => $Ventas_fortnite,
                    "mine"=> $Ventas_mogroft,
                    "totalVentas"=>$totalventa=$Ventas_cod+$Ventas_fortnite+$Ventas_mogroft,
                    "comCod"=> $comisionCod = (($Ventas_cod*34500)/100)*5,
                    "comFort"=> $comisionFort = (($Ventas_fortnite*58200)/100)*9,
                    "comMine"=> $comisionMine = (($Ventas_mogroft*8800)/100)*4,
                    "comTotal"=>$comisionTotal = $comisionCod+$comisionFort+$comisionMine,
				); 
				if (isset($_SESSION['persona'][$Vendedor])){
					echo "Se ha modificado el Vendedor: ".$Vendedor;
				}else{
					echo "Se ha registrado Un Vendedor";
				}		
				$_SESSION['persona'][$Vendedor]=$persona;
				print_r($_SESSION['persona']);	
			}
			
		}else if (isset($_POST['vaciar'])){
			if (!isset($_POST['ruts'])){
				echo "No hay Vendedores seleccionados";

			}else{	
				$ruts=$_POST['ruts'];
				print_r($ruts);

				foreach ($_SESSION['persona'] as $key =>$value){
					if (in_array($key,$ruts)){
						unset($_SESSION['persona'][$key]);
					}
				}
			echo "Vendedores Borrados";
			}
		}

	?>
     <!--Se muestran los datos que hay que ingresar-->
	<form method="post">
        <br>Vendedor
        <input type="text" id="vend" name="vend">
        <br>Ventas Cod
        <input type="number" id="cod" name="cod">
        <br>Ventas fortnite
        <input type="number" id="fort" name="fort">
        <br>Ventas Minecraft
        <input type="number" id="mine" name="mine">
        <br>
		<button type="submit" name="insertar">Insertar</button>
		<button type="submit" name="mostrar">Mostrar</button>
		<button type="submit" name="vaciar">Vaciar</button>
    
      
	<?php
    # boton para mostrar y creacion de tabla
		if (isset($_POST['mostrar'])){
			if (count($_SESSION['persona'])===0){
				echo "<p> No hay Personas </p>";
			}else {
				echo "<table border=1>";
          echo "<tr>";
          echo "<th></th>";
          echo "<th>Vendedor</th>";
          echo "<th>Imagen</th>";
          echo "<th>Ventas Cod</th>";
          echo "<th>Imagen</th>";
          echo "<th>Ventas Fortnite</th>";
          echo "<th>Imagen</th>";
          echo "<th>Ventas Minecraft</th>";
          echo "<th>Comision Cod</th>";
          echo "<th>Comision Fortnite</th>";
          echo "<th>Comision Minecraft</th>";
          echo "<th>Comision Total</th>";
          
          echo "</tr>";
				foreach ($_SESSION['persona'] as $key => $value){
					?>
					 <tr>
            <td><input type="checkbox" name="ruts[]" value="<?php echo $key; ?>"> </td>
              <td><?php echo $value['vend'];?> </td>
              <td ><img src="pics/cod.jpg" width = "80" height = "50"></td>
              <td><?php echo $value['cod'];?> </td>
              <td ><img src="pics/fornite.jpg" width = "80" height = "50"></td>
              <td><?php echo $value['fort'];?> </td>
              <td ><img src="pics/Minecraft.jpg" width = "80" height = "50"></td>
              <td><?php echo $value['mine'];?> </td>
              <td><?php echo $value['comCod'];?> </td>
              <td><?php echo $value['comFort'];?> </td>
              <td><?php echo $value['comMine'];?> </td>
              <td><?php echo $value['comTotal'];?> </td>
            <?php 
            ?>
              
		        <?php 
				}
				echo "</table>";
			} 
		}

	?>
	</form>
</body>
</html>