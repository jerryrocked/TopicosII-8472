<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="shortcut icon" href="imagenes/Iconsup.png" type="image/x-icon">
	<link rel="stylesheet" type="text/css" href="index.css">
	<title>Compras de juegos</title>
</head>
<body>
	<!--Barra arriba-->
	<nav id="Nav">
		<h1>
			Bienvenidos
		</h1>
	</nav>
	<h1 id="titulo">Top Juegos Vendidos</h1>
<center><img src="imagenes/callofduty.jpg" alt="" width="500" height="670"><img src="imagenes/fortnite.jpg" alt="" width="500" height="670"><img src="imagenes/minecraft.jpg" width="500" height="670"></center>

<?php 
		session_start();
		if (!isset($_SESSION['persona'])){
			$_SESSION['persona']= array();
		}
		if (isset($_POST['insertar'])){
			$nom = $_POST['NOM'];
			$ven1 = $_POST['VEN1'];
			$ven2 = $_POST['VEN2'];
			$ven3 = $_POST['VEN3'];
			if (empty($nom)||empty($ven1)||empty($ven2)||empty($ven3)){
				echo "Rellena todos los valores";
            }elseif(ctype_alpha($nom) == False){
                ?> <p id = pd> ERROR. ha ocurrido un problema con el  </p> <?php
            }elseif(ctype_digit($ven1) == False || $ven1 < 0){
                ?> <p id = pd>ERROR. Por Favor no ingresar letras, caracteres o numeros negativos"; </p> <?php
            }elseif(ctype_digit($ven2) == False || $ven2 < 0){
                ?> <p id = pd>ERROR. Por Favor no ingresar letras, caracteres o numeros negativos"; </p> <?php
            }elseif(ctype_digit($ven3) == False || $ven3 < 0){
                ?> <p id = pd>ERROR. Por Favor no ingresar letras, caracteres o numeros negativos"; </p> <?php
			}else {
				$persona = array(
					"Nombre" => $nom,
					"Cantidad ventas COD" => $ven1,
					"Cantidad ventas MIN" => $ven2,
					"Cantidad ventas FOR" => $ven1,
				); 
				if (isset($_SESSION['persona'][$nom])){
					echo "Se ha modificado la Persona con el nombre: ".$nom;
				}else{
					echo "Se ha registrado la persona";
				}		
				$_SESSION['persona'][$nom]=$persona;
				print_r($_SESSION['persona']);
			}
			
		}else if (isset($_POST['vaciar'])){
			if (!isset($_POST['Nombres'])){
				echo "No hay Personas seleccionadas";

			}else{	
				$Nombres=$_POST['Nombres'];
				print_r($Nombres);

				foreach ($_SESSION['persona'] as $key =>$value){
					if (in_array($key,$Nombres)){
						unset($_SESSION['persona'][$key]);
					}
				}
			echo "Persona(s) Borradas";
			}
		}

	?>
	<form method="post">
		<br>
		<label for="NOM">NOMBRE</label>
		<input type="text" id="NOM" name="NOM" />
		<br>
		<label for="">Cantidad Ventas COD</label>
		<input type="int" id="VEN1" name="VEN1" />
		<br>
		<br>
		<label for="">Cantidad Ventas MINECRAFT</label>
		<input type="int" id="VEN2" name="VEN2" />
		<br>
		<br>
		<label for="">Cantidad Ventas FORTNITE</label>
		<input type="int" id="VEN3" name="VEN3" />
		<br>
		<button type="submit" name="insertar">Insertar</button>
		<button type="submit" name="mostrar">Mostrar</button>
		<button type="submit" name="vaciar">Vaciar</button>
		
	<?php
		if (isset($_POST['mostrar'])){
			if (count($_SESSION['persona'])===0){
				echo "<p> No hay Personas </p>";
			}else {
				echo "<table border=1>";
				echo "<tr>";
				echo "<th></th>";
				echo "<th>NOMBRE</th>";
				echo "<th>Cantidad de ventas COD</th>";
				echo "<th>Cantidad de ventas MIN</th>";
				echo "<th>Cantidad de ventas FOR</th>";
				echo "<th>Cantidad de ventas totales</th>";
				echo "<th>Comision COD</th>";
				echo "<th>Comision MIN</th>";
				echo "<th>Comision FOR</th>";
				echo "<th>Comision total</th>";
				echo "<tr>";

				foreach ($_SESSION['persona'] as $key => $value){
					?>
					<tr>
						<td><input type="checkbox" name="Nombres[]" value="<?php echo $key; ?>"> </td>
						<td><?php echo $value['Nombre']; ?></td>
						<td><?php echo $value['Cantidad ventas COD']; ?></td>
						<td><?php echo $value['Cantidad ventas MIN']; ?></td>
						<td><?php echo $value['Cantidad ventas FOR']; ?></td>
						<td><?php echo $value['Cantidad ventas COD']+$value['Cantidad ventas MIN']+$value['Cantidad ventas FOR']?> </td>
						<td><?php echo $value['Cantidad ventas COD']*0.6; ?></td>
						<td><?php echo $value['Cantidad ventas MIN']*0.4; ?></td>
						<td><?php echo $value['Cantidad ventas FOR']*0.9; ?></td>
						<td><?php echo ($value['Cantidad ventas COD']*0.6)+($value['Cantidad ventas MIN']*0.4)+($value['Cantidad ventas FOR']*0.9); ?> </td>
					</tr>
					<?php 
				}
				echo "</table>";
			} 
		}

	?>
	</form>

</body>
</html>