<?php
session_start();
?>

<!DOCTYPE html>  
<html>  
<head>  
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge"> 
    <link rel="stylesheet" href="CSS/estilos.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fira+Sans+Condensed:ital,wght@1,600&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Fira+Sans+Condensed:ital,wght@1,600&display=swap" rel="stylesheet">
    
    <title>Vendijuegos</title>  
</head>  

<body>
    <div class="contenedor">
        <header class="header">
            <nav class = "menu">
            <img src="Imagenes/logo.png" alt="" width="60px" height="60px">
            <label class="logo">Vendijuegos</label>
            <ul class="menu_items">
                <li class="active"><a href="#">Inicio</a></li>
            </ul>
            <span class="btn_menu">
                <i class="fa fa-bars"></i>
            </span>
            </nav>
        </header>
        <div class="widget_1">
            <h3>Nuestros productos </h3>
        </div>
        <div class="widget_2">
            <ul>
                <li><img class="zoom" src="Imagenes/minecraft.jpeg" alt="" ></li>
                <div class="centrado">Minecraft</div>


            </ul>
        </div>
        <div class="widget_3">
            <ul>
                <li><img class="zoom" src="Imagenes/fornite.jpeg" alt=""></li>
                <div class="centrado" a>Fornite </div>

            </ul>
        </div>
        <div class="widget_4">
            <ul>
                <li><img class="zoom" src="Imagenes/cod.jpeg" alt=""></li>
                <div class="centrado">Call Of Duty</div>
            </ul>
        </div>

        <div class="widget_5">
            <ul>
                <h3> </h3>
                <!DOCTYPE html>
                    <!--PHP -->
                    <?php 
                		session_start();
                		if (!isset($_SESSION['persona'])){
                			$_SESSION['persona']= array();
                		}
                		if (isset($_POST['insertar'])){
                			//Datos Personales
                			$rut = $_POST['RUT'];
                			$nom = $_POST['NOM'];
                			$venta_cod = $_POST['V_COD'];//Call of duty
                			$venta_mc = $_POST['V_MC'];//Minecraft
                			$venta_for = $_POST['V_FOR'];//Fornite
                
                
                
                			//validacion 
                			if (empty($rut)||empty($nom)){
                				echo "Rellena todos los valores";

                			}else if (preg_match("/[a-z]/",$rut)){
                				echo "No se acepta LETRAS en el Rut(si es -k colocar 1)";

                			} else if (preg_match("/[0-9]/",$nom)){
                				echo "Solo se aceptan LETRAS en el NOMBRE";
  
                			}else if (!ctype_digit($venta_cod) || !ctype_digit($venta_mc) || !ctype_digit($venta_for)){
                				echo "Solo numeros enteros";
                			
                			}else {
               
                				$v_total = $venta_cod+$venta_mc+$venta_for;
     
                				$c_cod = 0.06;
                				$c_mc = 0.04;
                				$c_for = 0.09;
                				$c_total = (34500*$c_cod)*$venta_mc+(8800*$c_mc)*$venta_cod+(58200*$c_for)*$venta_for;
                
                				//Se agrego al vendedor
                				$persona = array(
                					"rut" => $rut,
                					"Nombre" => $nom,
                					//"Apellido" => $ape,
                					"Venta_cod" => $venta_cod,
                					"Venta_mc" => $venta_mc,
                					"Venta_for" => $venta_for,
                					"Venta_total" => $v_total,
                					"C_cod" => $c_cod,
                					"C_mc" => $c_mc,
                					"C_for" => $c_for,
                					"C_total" => $c_total,
                				);
                				//se modifica los datos atraves del rut
                				if (isset($_SESSION['persona'][$rut])){
                					echo "Se ha modificado la Persona con el RUT: ".$rut;
                				}else{
                					echo "Se ha registrado la persona";
                				}
                				$_SESSION['persona'][$rut]=$persona;
          	
                			}
                      
                		//Borrar
                		}else if (isset($_POST['vaciar'])){
                			if (!isset($_POST['ruts'])){
                				echo "No hay Personas seleccionadas";
                
                			}else{	
                				$ruts=$_POST['ruts'];
                				print_r($ruts);
                
                				foreach ($_SESSION['persona'] as $key =>$value){
                					if (in_array($key,$ruts)){
                						unset($_SESSION['persona'][$key]);
                					}
                				}
                			echo "Persona(s) Borradas";
                			}
                		}
                
                	?>
                	<!--Formulario para el registro de vendedores-->
                	<form method="post" align="Center">
                		<label for="RUT">RUT :</label><br>
                		<input type="number" id="RUT" name="RUT" />
                		<br>
                		<label for="NOM">NOMBRE :</label><br>
                		<input type="text" id="NOM" name="NOM" />
                		<br>
                		<label for="V_COD">VENTAS COD : </label><br>
                		<input type="number" id="V_COD" name="V_COD" />
                		<br>
                		<label for="V_MC">VENTAS MINECRAFT : </label><br>
                		<input type="number" id="V_MC" name="V_MC" />
                		<br>
                		<label for="V_FOR">VENTAS FORNITE : </label><br>
                		<input type="number" id="V_FOR" name="V_FOR" /><br>
                		<br>
                		<button type="submit" name="insertar">Insertar</button>
                		<button type="submit" name="mostrar">Mostrar</button>
                		<button type="submit" name="vaciar">Vaciar</button>
                		<button type="submit" name="vendedores">Vendedores</button>
                		<br>
                
            
                	</form>




              
            </ul>
        </div>

<div class="widget_6">
  <ul>
<?php
                		//Mostrar los vendedores
                		if (isset($_POST['mostrar'])){

                			if (count($_SESSION['persona'])===0){
                				echo "<p> No hay Personas registradas </p>";
                			}else {
                				echo "<table border=2 >";
                				echo "<tr>";
                				echo "<th></th>";
                				echo "<th>Rut</th>";
                				echo "<th>Nombre<br>Vendedor</th>";//Nombre de las columnas(tablas)
                				echo "<th>Cantidad<br>Ventas COD</th>";
                				echo "<th>Cantidad<br>Ventas MC</th>";
                				echo "<th>Cantidad<br>Ventas FOR</th>";
                				echo "<th>Total<br>Ventas</th>";
                				echo "<th>Comision<br>Call Of Duty</th>";
                				echo "<th>Comision<br>Minecraft</th>";
                				echo "<th>Comision<br>Fornite</th>";
                				echo "<th>Comision<br>Total</th>";
                				echo "<tr>";
                
                				foreach ($_SESSION['persona'] as $key => $value){
                					
                					?>
                					<tr>
                						<td><input type="checkbox" name="ruts[]" value="<?php echo $key; ?>"> </td>
                						<td><?php echo $value['rut']; ?></td>
                						<td><?php echo $value['Nombre']; ?></td>
                						<td><?php echo $value['Venta_cod']; ?></td>
                						<td><?php echo $value['Venta_mc']; ?></td>
                						<td><?php echo $value['Venta_for']; ?></td>
                						<td><?php echo $value['Venta_total']; ?></td>
                						<td><?php echo $value['C_cod']; ?></td>
                						<td><?php echo $value['C_mc']; ?></td>
                						<td><?php echo $value['C_for']; ?></td>
                						<td><?php echo $value['C_total']; ?></td>
                					</tr>
                					<?php 
                				}
                				echo "</table>";
                			} 
                		}
                
                	?>
    
  </ul>
</div>

      
        <footer class="footer">
            <h2>Abierta	Lunes a Domingo de 10:00 a 20:30 hrs
Av. Andrés Bello 2465, Local 4133, piso 4, Providencia, RM	+56227630664</h2>
        </footer>
    </div>
</body>  
</html>  