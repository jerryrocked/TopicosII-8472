<?php 
	
		session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/Estilo.css"> 
  	<link rel="stylesheet" href="https://cdn.jsdelivr.net/bxslider/4.2.12/jquery.bxslider.css">
      	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  	<script src="https://cdn.jsdelivr.net/bxslider/4.2.12/jquery.bxslider.min.js"></script> 
    	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">  
  	<title>PAGINA WEB </title>
	
	<link rel="stylesheet" href="/css/styles.css">
</head>
<body>

	<header>

        
        <div id="header-inner"> <!-- ENCABEZADO -->
          <a href="#" id="logo"> <!-- # ENLACE A MARCADORES  -->
            <img src="img/pics/logowo.jpg" alt="">
          </a>

          <nav> <!-- # SECCION DE NAVEGACION  -->
            <a href="#" id="menu-icon"> <!-- # ENLACE AL INICIO  -->
              <i class="fa fa-bars"></i>
            </a>
            <ul class="menu">
              <li>
                <a href="index.html" class="current">
                  <!-- # ENLACE A LA PAGINA PRINCIPAL  -->
                  Inicio
                </a>
              </li>
              <li>
                <a href="index.html">
                  <!-- # ENLACE A MEDIO AMBIENTE  -->
                  Call Of Duty
                </a>
              </li>
              <li>
                <a href="index.html">
                  <!-- # ENLACE A CONTAMINACION  -->
                  Fornite
                 
                </a>
              </li>
              <li>
                <a href="index.html">
                  <!-- # ENLACE A FUTBOL  -->
                  Minecraft
                </a>
              </li>
              <li>
                <a href="index.html">
                  <!-- # ENLACE A CONTACTOS  -->
                  Contacto
                </a>
              </li>
            </ul>
          </nav>
        </div>
    </header>

	<?php 
		
		if (!isset($_SESSION['persona'])){
			$_SESSION['persona']= array();
		}

		
		if (isset($_POST['insertar'])){

		
			$rut = $_POST['RUT'];
			$nom = $_POST['NOM'];
			$ape = $_POST['APE'];
			$callofdutyc = $_POST['CALLC'];
			$minecraftc = $_POST['MINEC'];
			$fornitec = $_POST['FORNC'];

		
			if (empty($rut)||empty($nom)||empty($ape)||empty($callofdutyc)||empty($minecraftc)||empty($fornitec)){
				echo "Rellena todos los valores";

			} else if (!ctype_alpha($nom) || !ctype_alpha($ape)){
				echo "Solo se admiten letras en los campos nombre y apellido";

			} else if (!ctype_digit($callofdutyc) || !ctype_digit($minecraftc) || !ctype_digit($fornitec)){
				echo "Solo se pueden colocar numeros en las cantidades de juegos vendidos";

			} else {

		
				$totalventas = 0.06*34500*(intval($callofdutyc))+0.04*8800*(intval($minecraftc))+0.09*58200*(intval($fornitec));

				$persona = array(
					"rut" => $rut,
					"Nombre" => $nom,
					"Apellido" => $ape,
					"callofdutycantidad" => intval($callofdutyc),
					"minecraftcantidad" => intval($minecraftc),
					"fornitecantidad" => intval($fornitec),
					"totalvent" => intval($callofdutyc)+intval($minecraftc)+intval($fornitec),
					"callofdutycom" => "6%",
					"minecraftcom" => "4%",
					"fornitecom" => "5%",
					"comisionTotal" => $totalventas,
				); 

				
				if (isset($_SESSION['persona'][$rut])){
					echo "Se ha modificado la Persona con el RUT: ".$rut;
			
				}else{
					echo "Se ha registrado la persona";
				}		

	
				$_SESSION['persona'][$rut]=$persona;
				
      }
    }else if (isset($_POST['vaciar'])){
  			if (!isset($_POST['ruts'])){
  				echo "No hay Personas seleccionadas";
  
  			}else{	
  				$ruts=$_POST['ruts'];
  				print_r($ruts);
  
  				foreach ($_SESSION['persona'] as $key =>$value){
  					if (in_array($key,$ruts)){
  						unset($_SESSION['persona'][$key]);
  					}
				}
			echo "Persona(s) Borradas";
			}
		}
	?>

	
	<form method="post">
		<caption><h2>Datos Del vendedor</h2></caption>
		<label for="RUT"><h3>Rut Vendedor</h3></label>
		<center><input type="text" id="RUT" name="RUT" /></center>
		<br>
		<label for="NOM"><h3>Nombre Vendedor</h3></label>
		<center><input type="text" id="NOM" name="NOM" /></center>
		<br>
		<label for="RUT"><h3>Apellido Vendedor</h3></label>
		<center><input type="text" id="APE" name="APE" /></center>
		<br>
		<label for="RUT"><h3>Cantidad ventas COD</h3></label>
		<center><input type="text" id="CALLC" name="CALLC" /></center>
		<br>
		<label for="RUT"><h3>Cantidad ventas Minecraft</h3></label>
		<center><input type="text" id="MINEC" name="MINEC" /></center>
		<br>
		<label for="RUT"><h3>Cantidad ventas Fornite</h3></label>
		<center><input type="text" id="FORNC" name="FORNC" /></center>
		<br>
		<center><button type="submit" name="insertar">Insertar</button>
		<button type="submit" name="mostrar">Mostrar</button>
		<button type="submit" name="vendedores">Vendedores</button>
		<button type="submit" name="vaciar">Vaciar</button></center>
	
	
	<?php
		// esta seccion es para el boton mostrar
		if (isset($_POST['mostrar'])){
			if (count($_SESSION['persona'])===0){
				echo "<p> No hay Personas </p>";
			}else {
				echo "<table border=2>";
				echo "<tr>";
				echo "<th></th>";
				echo "<th><p>Rut Vendedor</p></th>";
				echo "<th><p>Nombre Vendedor</p></th>";
				echo "<th><p>Apellido Vendedor</p></th>";
				echo "<th><p>Cantidad ventas COD</p></th>";
				echo "<th><p>Cantidad ventas Minecraft</p></th>";
				echo "<th><p>Cantidad ventas Fornite</p></th>";
				echo "<th><p>Total</p></th>";
				echo "<th><p>Comisión Call of Duty</p></th>";
				echo "<th><p>Comisión Minecraft</p></th>";
				echo "<th><p>Comisión Fornite</p></th>";
				echo "<th><p>COMISIÓN TOTAL</p></th>";
				echo "<tr>";

				foreach ($_SESSION['persona'] as $key => $value){
					?>
					<tr>
						<td><input type="checkbox" name="ruts[]" value="<?php echo $key; ?>"> </td>
						<td><p><?php echo $value['rut']; ?></p></td>
						<td><p><?php echo $value['Nombre']; ?></p></td>
						<td><p><?php echo $value['Apellido']; ?></p></td>
						<td><p><?php echo $value['callofdutycantidad']; ?></p></td>
						<td><p><?php echo $value['minecraftcantidad']; ?></p></td>
						<td><p><?php echo $value['fornitecantidad']; ?></p></td>
						<td><p><?php echo $value['totalvent']; ?></p></td>
						<td><p><?php echo $value['callofdutycom']; ?></p></td>
						<td><p><?php echo $value['minecraftcom']; ?></p></td>
						<td><p><?php echo $value['fornitecom']; ?></p></td>
						<td><p><?php echo $value['comisionTotal']; ?></p></td>
					</tr>
					<?php 
				}
				echo "</table>";
			} 
		}

// esta seccion es para el boton vendedores
		if (isset($_POST['vendedores'])){
			if (count($_SESSION['persona'])===0){
				echo "<p> No hay Personas </p>";
			}else {
				echo "<table>";
				echo "<tr>";
				echo "<th></th>";
				echo "<th><p>Rut Vendedor</p></th>";
				echo "<th><p>Nombre Vendedor</p></th>";
				echo "<th><p>Apellido Vendedor</p></th>";

				echo "<tr>";

				foreach ($_SESSION['persona'] as $key => $value){
					?>
					<tr>
						<td><input type="checkbox" name="ruts[]" value="<?php echo $key; ?>"> </td>
						<td><p><?php echo $value['rut']; ?></p></td>
						<td><p><?php echo $value['Nombre']; ?></p></td>
						<td><p><?php echo $value['Apellido']; ?></p></td>
					</tr>
					<?php 
				}
				echo "</table>";
        
			} 
		}

	?>
  <p></p>
   <center><a href="index.html" class="current2 btn1" >
       Volver
      </a></center>
	</form>
</body>
</html>