<html>
<head>
    <title>Venta de Juegos</title>   
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <link rel="stylesheet" type="text/css" href="estilo.css">
</head>
<body>
    <!---- inicio-->
        <div class="banner" >
            <div class="navbar">
                <a href="index.php"><img src="https://scontent-scl2-1.xx.fbcdn.net/v/t1.18169-9/10432460_10155172261395246_2279534711287757186_n.png?_nc_cat=102&ccb=1-7&_nc_sid=174925&_nc_eui2=AeF5wunEe9GCkqm6W8E2rGBnqBkTfCVa7jqoGRN8JVruOjZKY_9Z9UYHh1TTv1L2SZA&_nc_ohc=v9VwbTmMBQkAX-Dwkuc&_nc_ht=scontent-scl2-1.xx&oh=00_AT8a1lDq63ksa0bTT6S8lNnJa3cc8pLSWh5R9AGiLfXyMg&oe=62B4356B" class="logo"></a>
                <ul>
                  <li><a href="index.php">Home</a></li>
                  <li><a href="#fjuegos">Juegos</a></li>
                  <li><a href="#iniciarsesion">Log in</a></li>
                </ul>
            </div>
            <div class="texto-central">
                <h1>Tienda XYZ</h1>
            </div>
        </div>
        
 <main>
        </section>
        <!--descripcion de los fjuegos-->
        <section class="fjuegos img" id="fjuegos">
            <h2 class="titulo">Juegos mas Vendidos</h2>
                <a href="https://www.callofduty.com/es"><img src="https://www.muycomputer.com/wp-content/uploads/2019/08/Call-of-Duty-Modern-Warfare-2.jpg"></a>
                <h3>Call of Duty Modern Warfare (2019)</h3>
                <del><FONT COLOR=red> 50.000CLP </del>
                <p class="fjuegos"><FONT COLOR=green>Oferta = $34.500CLP</p>
          
                <a href="https://www.minecraft.net/es-es"><img src="https://cdn.hobbyconsolas.com/sites/navi.axelspringer.es/public/styles/1200/public/media/image/2021/07/minecraft-2397153.jpg?itok=pdw9_9px"></a>
                <h3><FONT COLOR=black>MINECRAFT</h3>
                <p class="fjuegos">8.800 CLP</p>
          
                <a href="https://www.epicgames.com/fortnite/es-ES/home"><img src="https://www.esportmaniacos.com/wp-content/uploads/2022/03/Fortnite-scaled1-780x470.jpg"></a>
                <h3>FORTNITE</h3>
                <p class="fjuegos">58.200CLP</p>
        </section>


   
            <!---inicio de sesion-->
        <section class="contenido" id="iniciarsesion">
            <h2 class="titulo"> Log in Tienda</h2>
            <form action="tabla.php" method="POST">
              
              <p><label for="user">Nombre de usuario</label>
		          <input type="text" name="user"></p>
                
		          <p><label for="pass">Contraseña &nbsp&nbsp&nbsp&nbsp&nbsp &nbsp&nbsp&nbsp&nbsp&nbsp</label>
		          <input type="text" name="pass"></p>

                <p><input type="submit" value="Log in"></p>
            </form>

              
        </section>
    </main>

    <!--footer de pagina-->
    <footer>
        <a href="http://localhost/Tarea2/index.php">
        <h2 align="center"><FONT COLOR=yellow> Comparte la pagina</h2>
    </footer>
</body>
</html>
