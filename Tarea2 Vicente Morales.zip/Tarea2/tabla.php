<?php @session_start(); 
error_reporting(0);
?>
<html>
  <head>
    <title>Tabla de ventas</title>   
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <link rel="stylesheet" type="text/css" href="estilo.css">
</head>
<body>

<div class="banner" >
            <div class="navbar">
                <a href="index.php"><img src="https://scontent-scl2-1.xx.fbcdn.net/v/t1.18169-9/10432460_10155172261395246_2279534711287757186_n.png?_nc_cat=102&ccb=1-7&_nc_sid=174925&_nc_eui2=AeF5wunEe9GCkqm6W8E2rGBnqBkTfCVa7jqoGRN8JVruOjZKY_9Z9UYHh1TTv1L2SZA&_nc_ohc=v9VwbTmMBQkAX-Dwkuc&_nc_ht=scontent-scl2-1.xx&oh=00_AT8a1lDq63ksa0bTT6S8lNnJa3cc8pLSWh5R9AGiLfXyMg&oe=62B4356B" class="logo"></a>
                <ul>
                  <li><a href="index.php">Inicio</a></li>
                </ul>
            </div>
            <div class="texto-central">
                <h1>Tienda de Juegos XYZ</h1>
            </div>
        </div>

  
<?php
#declaracion de variables y arreglo
  if (!isset($_SESSION['vendedor'])){
    $_SESSION['vendedor']=array();
  }
  if (isset($_POST['insertar'])){
    $nom= $_POST['Nom'];
    $cod= $_POST['cod'];
    $mc= $_POST['mc'];
    $ft= $_POST['ft'];
    $preciocod= 34500;
    $preciomc= 8800;
    $precioft= 58200;
    $total= ($preciocod*$cod)+($preciomc*$mc)+($precioft*$ft);
    $comisioncod= (($preciocod*0.06)*$cod);
    $comisionmc= (($preciomc*0.04)*$mc);
    $comisionft= (($precioft*0.09)*$ft);
    $comisiontotal= $comisioncod+$comisionmc+$comisionft;


    if (empty($nom)||empty($cod)||empty($mc)||empty($ft)){
      echo "Rellena todos los valores";
    }elseif (ctype_alpha($nom) == false || is_numeric($cod) == false || $cod<0 || $mc<0 || $ft<0 || is_numeric($mc) == false || is_numeric($ft) == false ){
        echo "Ingrese los valores correctamente";
      
    }else {
      if($cod>$mc && $cod>$ft){
        $foto = "<img src=\"img/warzonelogo.png\">";
      }
      else if ($mc > $cod && $mc>$ft){
          $foto = "<img src=\"img/minecraftlogo.png\">";
      } else {
          $foto = "<img src=\"img/fortnitelogo.png\">";
      }

      $vendedor = array(
        "Nom" => $nom,
        "cod" => $cod,
        "mc" => $mc,
        "ft" => $ft,
        "total" => $total,
        "comisioncod" => $comisioncod,
        "comisionmc" => $comisionmc,
        "comisionft" => $comisionft,
        "comisiontotal" => $comisiontotal,
        "foto" => $foto,
      );
      if (isset($_SESSION['vendedor'[$nom]])){
        echo "Se ha modificado el vendedor: ".$nom;
      }else{
        echo "<br></br>";
        echo "Se han registrado las ventas";
      }
      $_SESSION['vendedor'][$nom]=$vendedor;
    }
    
  }else if (isset($_POST['vaciar'])){
    session_start(); 
    session_destroy();
    }else{
      $nombre_vendedores = $_POST['nombre_vendedores'];
      print_r($nombre_vendedores);
    
      foreach ($_SESSION['vendedor'] as $key => $value){
        if (in_array($key,)){
          unset($_SESSION['vendedor'][$key]);
        }
      }
    }
  
  ?>

  <!--cajas de texto-->
  <form method="post">
    <br>Nombre del vendedor
    <input type="text" id="Nom" Name="Nom">
    <br>Cantidad de ventas COD WZ
    <input type="int" id="cod" Name="cod">
    <br>Cantidad de ventas MINECRAFT
    <input type="int" id="mc" Name="mc">
    <br>Cantidad de ventas FORTNITE
    <input type="int" id="ft" Name="ft">

<!--botones-->
    <br></br>
    <button type="submit" name="insertar"> Insertar </button>
    <button type="submit" name="mostrar"> Mostrar </button>
    <button type="submit" name="vaciar"> Vaciar </button>
    

    <!--tabla-->
<?php
  if (isset($_POST['mostrar'])){
    if (!count($_SESSION['vendedor']===0)){
      echo "<p> No hay Personas </p>";
    }else {
      echo "<table border=1>";
      echo "<tr>";
      echo "<th></th>";
      echo "<th>Nombre vendedor</th>";
      echo "<th>Cantidad de ventas COD</th>";
      echo "<th>Cantidad de ventas MC</th>";
      echo "<th>Cantidad de ventas FT</th>";
      echo "<th>Total de ventas</th>";
      echo "<th>Comision total</th>";
      echo "<th>Comision Call of Duty</th>";
      echo "<th>Comision Minecraft</th>";
      echo "<th>Comision Fortnite</th>";
      echo "<th>Imagen del juego</th>";
      echo "</tr>";
      foreach ($_SESSION['vendedor'] as $key => $value){
?>  
      <tr>
        <td><input type="checkbox" name="nombre_vendedores[]" value= "<?php echo $key; ?>"></td>
        <td> <?php echo $value['Nom']; ?> </td>
        <td> <?php echo $value['cod']; ?> </td>
        <td> <?php echo $value['mc']; ?> </td>
        <td> <?php echo $value['ft']; ?> </td>
        <td> <?php echo $value['total']; ?> </td>
        <td> <?php echo $value['comisiontotal']; ?> </td>
        <td> <?php echo $value['comisioncod']; ?> </td>
        <td> <?php echo $value['comisionmc']; ?> </td>
        <td> <?php echo $value['comisionft']; ?> </td>
        <td> <?php echo $value['foto']; ?> </td>
      </tr>
      <?php
      }
      echo "</table>";
    }
  }    
      ?>
    <button type="submit" name="resultados"> RESULTADOS </button>
    <br></br>
    <?php

    if (isset($_POST['resultados'])){
      $mejorvendedor = array_column($_SESSION['vendedor'], 'comisiontotal', 'Nom',);
      $nom = array_search (max($mejorvendedor), $mejorvendedor, true);
      echo "<br><h2>La mejor comision es de: ". $nom . "<br> con total de: ". max($mejorvendedor)."</h2>";
  }
    
    ?>
  </form>
    <!--pie de pagina-->
    <footer>
        <h2 align="center">&copy; Vicente Morales</h2>
    </footer>
  
</body>
</html>