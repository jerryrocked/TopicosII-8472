<html>
  <head>
    <title>XYZ Call of Duty</title>
    <meta charset = "utf-8">
    <link rel = "stylesheet" TYPE="text/css" href = "css/stilos.css">
    <script src="https://kit.fontawesome.com/b0e913bd1c.js" crossorigin="anonymous"></script>
    <script defer src ="index.js"></script>
    <style>
      .button {
        border: none;
        color: white;
        padding: 15px 32px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        margin: 4px 2px;
        cursor: pointer;
      }
      
      .button1 {background-color: rgba(194,197,187,255);
                text-align: center;
                line-height: 1.1;
                letter-spacing: 2px;
                font-weight: bold;
                font-size: 24px;
                font-family: 'VA-Text-Caps-Bold';
                border: 1px solid #f4f4f4;
                color: #171a1a;
                margin-left: 20px;} /* Green */
      .button2 {background-color: #785c2c;
                text-align: center;
                line-height: 1.1;
                letter-spacing: 2px;
                font-weight: bold;
                font-size: 24px;
                font-family: 'VA-Text-Caps-Bold';
                border: 1px solid #f4f4f4;
                color: white;
                margin-left: 20px;;
                
      } ;/* Blue */
      </style>
  </head>
  <body>
    <header class = "header">
      <nav class = "nav">  
        <a href="compra.php" class="menu-icon nav-link"> XYZ </a>
        <button class ="nav-toggle" aria-label="Abrir Menu">
          <i class="fa-solid fa-bars"></i>
        </button>
        <ul class = "nav-menu">
          <li class ="nav-menu-item">
            <a href = "#" class = "nav-menu-link nav-link">Inicio</a>
          </li>
          <li class ="nav-menu-item">
            <a href = "maincra.html" class = "nav-menu-link nav-link">Minecraft</a>
          </li>
          <li class ="nav-menu-item">
            <a href = "fornite.html" class = "nav-menu-link nav-link nav-menu-link_active">Fornite</a>
          </li>
        </ul>
      </nav>
    </header>
    <section class = "container">
        <img src="./img/1366_2000.jpeg" alt="" width="100%">
      </section>
        <form action="compra.php">
          <center><p class="titulo">Precio: 34.500  Comision = 6%</p>
          <button class ="button button1" type="submit">Comprar</button></center>
        </form>
        <form action="https://www.callofduty.com/es/">
          <center><button class ="button button2" type="submit">Mas Informacion</button></center>
        </form>
    
    <div class="ppp">
      
      <center>
        <p>Una nube oscura se cierne sobre Caldera... Se avecina una tormenta. Las incesantes batallas han convertido la frondosa isla en una sombra de lo que era, y varios lugares a lo largo de las costas y alrededor de las cimas de la isla ahora parecen misteriosamente arrasados. Se acerca algo, algo grande.</p>
      </center>
    </div>
    <section class="columnas">
      <div id="column-1">
        <center>
          <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSnifYff5W4O9vcSn5Uw9YkFRsaMsniUyhvzLzGaXOzHwOvfmJ-2XvMzPxmBlbhDlN2IoA&usqp=CAU" width="30%" alt="">
        </center>  
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Magnam eum consequuntur voluptate laudantium adipisci hic ipsam, nesciunt reiciendis tempora dolore velit voluptatum molestiae illum sequi laborum nam, sunt autem natus?</p>
      </div>  
      <div id="column-2">
        <center>
          <img src="https://sm.ign.com/ign_es/game/c/call-of-du/call-of-duty-black-ops-cold-war_tsew.jpg" width="50%" alt="">
        </center>  
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Magnam eum consequuntur voluptate laudantium adipisci hic ipsam, nesciunt reiciendis tempora dolore velit voluptatum molestiae illum sequi laborum nam, sunt autem natus?</p>
      </div> 
      <div id="column-3">
        <center>
          <img src="https://image.api.playstation.com/cdn/UP0002/CUSA03522_00/t7SHaSjuUXFZ3VHl6U4FuSFrDMtkOIyP.png" width="50%" alt="">
        </center>  
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Magnam eum consequuntur voluptate laudantium adipisci hic ipsam, nesciunt reiciendis tempora dolore velit voluptatum molestiae illum sequi laborum nam, sunt autem natus?</p>
      </div> 
    </section>
     
  </body>
</html>