<?php session_start(); ?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel = "stylesheet" TYPE="text/css" href = "css/compra.css">
    <title>Comprar</title>
</head>
<body>
    <header class = "header">
      <nav class = "nav">  
        <a href="#"> XYZ </a>
        <button class ="nav-toggle" aria-label="Abrir Menu">
          <i class="fa-solid fa-bars"></i>
        </button>
        <ul class = "nav-menu">
          <li class ="nav-menu-item">s
            <a href = "index.php" class = "nav-menu-link nav-link">Call of Duty</a>
          </li>
          <li class ="nav-menu-item">
            <a href = "maincra.html" class = "nav-menu-link nav-link">Minecraft</a>
          </li>
          <li class ="nav-menu-item">
            <a href = "fornite.html" class = "nav-menu-link nav-link nav-menu-link_active">Fornite</a>
          </li>
        </ul>
      </nav>
    </header>
  <br>
  <br>

  <img src ="https://depor.com/resizer/iCsBAaTBRtBycWqjff2AiDXMhBc=/1200x675/smart/filters:format(jpeg):quality(75)/cloudfront-us-east-1.images.arcpublishing.com/elcomercio/LCYYJT7J6VG6VFF5HHRAHGLOBA.jpg"/>
    <?php 
		
		if (!isset($_SESSION['persona'])){
			$_SESSION['persona']= array();
		}
		if (isset($_POST['insertar'])){
      $rut = $_POST['RUT'];
			$nom = $_POST['NOM'];
			$cod = $_POST['COD'];
			$min = $_POST['MIN'];
      $for = $_POST['FOR'];
	

			if (empty($rut)||empty($nom)||empty($cod)||empty($min)||empty($for)){
				echo "Rellena todos los valores";
			}else 
      {
        $total = $cod + $min + $for;
        $ctotal = $cod * 0.06 * 34500 + $mid * 0.04 * 8800 + $for * 0.09 * 58200;
				$persona= array(
          "rut" => $rut,
          "nombre" => $nom,
					"Vcod" => $cod,
					"Vmin" => $min,
          "Vfor" => $for,
          "Vtol" => $total,
          "Ctol" => $ctotal,
        );
        if (empty($rut)||empty($nom)){
				echo "Rellena todos los valores";
			//validacion en caso que el usuario ingresara letras no se podra registrar
			}else if (preg_match("/[a-z]/",$rut)){
				echo "No se acepta LETRAS en el Rut(si es -k colocar 1)";
			//validacion en caso que el usuario ingresara numeros no se podra registrar
			} else if (preg_match("/[0-9]/",$nom)){
				echo "Solo se aceptan LETRAS en el NOMBRE";
			//validacion para que el usuario ingrese numeros enteros.
			}else if (!ctype_digit($cod) || !ctype_digit($min) || !ctype_digit($for)){
				echo "Solo numeros enteros";
			
			}
      else if (isset($_SESSION['persona'][$rut])){
					echo "Se ha modificado la Persona con el RUT: ".$rut;
				}else{//se registra en caso del que rut sea diferente
					echo "Se ha registrado la persona";
				}
				$_SESSION['persona'][$rut]=$persona;
			}
		//funcion para vaciar la tabla
		}else if (isset($_POST['vaciar'])){
			if (!isset($_POST['ruts'])){
				echo "No hay Personas seleccionadas";

			}else{	
				$ruts=$_POST['ruts'];
				print_r($ruts);

				foreach ($_SESSION['persona'] as $key =>$value){
					if (in_array($key,$ruts)){
						unset($_SESSION['persona'][$key]);
					}
				}
			echo "Persona(s) Borradas";
			}
		}
        
         
	?>
    <center>
    <form method="post">
    <label for="RUT">Rut</label>
		<input type="text" id="RUT" name="RUT" />
		<br>
		<label for="NOM">Nombre Vendedor</label>
		<input type="text" id="NOM" name="NOM" />
		<br>
		<label for="COD">Cantidad ventas COD</label>
		<input type="number" id="COD" name="COD" />
		<br>
        <label for="MIN">Cantidad ventas MIN</label>
		<input type="number" id="MIN" name="MIN" />
		<br>
        <label for="FOR">Cantidad ventas FOR</label>
		<input type="number" id="FOR" name="FOR" />
    <br>
		<button type="submit" name="insertar">Insertar</button>
		<button type="submit" name="mostrar">Mostrar</button>
    <button type="submit" name="vaciar">Vaciar</button>
    

	<?php
		if (isset($_POST['mostrar'])){
			if (count($_SESSION['persona'])===0){
				echo "<p> No hay Personas </p>";
			}else {
				echo "<table border=1>";
				echo "<tr>";
				echo "<th></th>";
				echo "<th>Nombre Vendedor</th>";
				echo "<th>Cantidad ventas COD</th>";
				echo "<th>Cantidad ventas MIN</th>";
        echo "<th>Cantidad ventas FOR</th>";
				echo "<th>Total ventas</th>";
				echo "<th>Comision COD</th>";
        echo "<th>Comision MIN</th>";
				echo "<th>Comision FOR</th>";
        echo "<th>Comision Total</th>";
				echo "<tr>";

                foreach ($_SESSION['persona'] as $key => $value){
                ?>
            <tr>
						<td><input type="checkbox" name="ruts[]" value="<?php echo $key; ?>"> </td>
						<td><?php echo $value['nombre']; ?></td>
						<td><?php echo $value['Vcod']; ?></td>
						<td><?php echo $value['Vmin']; ?></td>
            <td><?php echo $value['Vfor']; ?></td>
            <td><?php echo $value['Vtol']; ?></td>
						<td><?php echo "6%"; ?></td>
            <td><?php echo "4%"; ?></td>
            <td><?php echo "9%"; ?></td>
            <td><?php echo $value['Ctol']; ?></td>    
           
                       
                        
					</tr>
					<?php 
				}
				echo "</table>";        
			} 
		}

	?>
  </center>
	</form>
  <footer>
  <p>Industrias XYZ<br>
  <a href="mailto:hege@example.com">XYZ@example.com</a></p>
</footer>

</body>
</html>