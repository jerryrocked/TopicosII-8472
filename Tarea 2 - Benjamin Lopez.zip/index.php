<?php session_start(); ?>

<html>
    
  <head>
    <meta charset="utf-8">
    <title> Vendedores </title>
    <link href="css/style.css" rel="stylesheet" type="text/css">
  </head>
    
    <body>
        
        <header>
            <img src="img/logo-png.png" id="logo">
            <h1> STEM </h1>
        </header>
        
        <!-- Crear los vendedores e Insertar-->
        <?php
        if (!isset($_SESSION['vendedor'])){        
            $_SESSION['vendedor']=array();
            
            
        }
        if (isset($_POST['insertar'])){
            $nom= $_POST['NOM'];        
            $cantCOD= $_POST['CANTCOD'];        
            $cantMIN= $_POST['CANTMIN'];        
            $cantFORT= $_POST['CANTFORT'];      
            
            if (empty($nom)||empty($cantCOD)||empty($cantMIN)||empty($cantFORT)){
                ?> <p id = pd>Rellenar valores</p> <?php
            }elseif(ctype_alpha($nom) == False){
                ?> <p id = pd> Nombre mal Ingresado. Por favor no ingresar numeros o caracteres </p> <?php
            }elseif(ctype_digit($cantCOD) == False || $catCOD < 0){
                ?> <p id = pd>Error al ingresar Datos en Cantidad COD. Por Favor no ingresar letras, caracteres o numeros negativos"; </p> <?php
            }elseif(ctype_digit($cantMIN) == False || $cantMIN < 0){
                ?> <p id = pd>Error al ingresar Datos en Cantidad Minecraft. Por Favor no ingresar letras, caracteres o numeros negativos"; </p> <?php
            }elseif(ctype_digit($cantFORT) == False || $cantFORT < 0){
                ?> <p id = pd>Error al ingresar Datos en Cantidad Fortnite. Por Favor no ingresar letras, caracteres o numeros negativos"; </p> <?php
            }else{
                $vendedor = array(
                    "Nom" => $nom,
                    "CantCOD" => $cantCOD,
                    "CantMIN" => $cantMIN,
                    "CantFORT" => $cantFORT,
                );
                if (isset($_SESSION['vendedor'[$nom]])){
                    echo "Se ha modificado la Persona con el Nombre: ".$nom;
                }else{
                    echo "Se ha registrado la persona";
                }
                $_SESSION['vendedor'][$nom]=$vendedor;
                
            }
        }
        ?> 
        
        <section id="margen">
        <!-- Botones -->
        <form method="post" >
            <br>NOMBRE COMPLETO
            <input type="text" id="NOM" name="NOM">
            <br>
            <br>CANTIDAD VENTAS COD
            <input type="text" id="CANTCOD" name="CANTCOD">
            <br>
            <br>CANTIDAD VENTAS MINECRAFT
            <input type="text" id="CANTMIN" name="CANTMIN">
            <br>
            <br>CANTIDAD VENTAS FORTNITE
            <input type="text" id="CANTFORT" name="CANTFORT">
            <br><br>
            <button type="submit" name="insertar"> Insertar </button>
            <button type="submit" name="mostrar"> Mostrar Vendedores</button>
            <button type="submit" name="Mayor_C"> Mostrar Vendedor con Mayor Comision </button>
            <br>
            <a href="Lista.html">
                Ver Catalogo de Juegos
            </a>
    
        <!-- Mostrar Tabla -->
        <?php
            if (isset($_POST['mostrar'])){
                if (!count($_SESSION['vendedor'])===0){
                    echo "<p> No hay Personas </p>";
                }else {
                    echo"<div style=overflow-x:auto;>";
                    echo "<table width=100% border=1 cellspacing=0 cellpadding=6>";
                    echo "<table border=1>";
                    echo "<tr>";
                    echo "<th>Nombre Completo</th>";
                    echo "<th>Cantidad Ventas COD</th>";
                    echo "<th>Cantidad Ventas MINECRAFT</th>";
                    echo "<th>Cantidad Ventas FORTNITE</th>";
                    echo "<th>Total Ventas</th>";
                    echo "<th>Comision COD</th>";
                    echo "<th>Comision MINECRAFT</th>";
                    echo "<th>Comision FORTNITE</th>";
                    echo "<th>Comision Total</th>";
                    echo "<th>Imagen del Juego mas Vendido</th>";
                    echo "</tr>";
                    
                    foreach ($_SESSION['vendedor'] as $key => $value){
        ?>
                        <tr>
                            
                            <td> <?php echo $value['Nom']; ?> </td>
                            <td> <?php echo $value['CantCOD']; ?> </td>
                            <td> <?php echo $value['CantMIN']; ?> </td>
                            <td> <?php echo $value['CantFORT']; ?> </td>
                            <!-- total ventas -->
                            <td> <?php echo ($value['CantCOD']*34500)+($value['CantMIN']*8800)+($value['CantFORT']*58200)?> </td>
                            <!--comision COD 2070 -->
                            <td> <?php echo ($value['CantCOD']*2070); ?> </td>
                            <!--comision Minecraft 352 -->
                            <td> <?php echo ($value['CantMIN']*352); ?> </td>
                            <!--comision Fortnite 5238 -->
                            <td> <?php echo ($value['CantFORT']*5238); ?> </td>
                            <!-- total comision -->
                            <td> <?php echo ($value['CantCOD']*2070)+($value['CantMIN']*352)+($value['CantFORT']*5238); ?> </td>
                            <!-- Imagen -->
                            <td>  <?php if ($value['CantCOD'] > $value['CantMIN'] && $value['CantCOD'] > $value['CantFORT']) { ?>
                                <img src="img/COD.jpg" id="imgCOD"> <p>Ventas: <?php echo($value['CantCOD']*34500) ?> </p> <?php }elseif($value['CantMIN'] > $value['CantFORT']){ ?>
                                <img src="img/minecraft.jpeg" id="imgMIN"> <p>Ventas: <?php echo($value['CantMIN']*8800) ?> </p> <?php }else{?>
                                <img src="img/fortnite.jpg" id="imgFORT"> <p>Ventas: <?php echo($value['CantFORT']*58200) ?> </p> <?php }?>
                        </td>
                        </tr>
        <?php
                    }
                    echo "</table>";
                }
            }
        ?>
                
        <!-- Mostrar al de Mayor Comision -->       
        <?php
            if (isset($_POST['Mayor_C'])){
                if (!count($_SESSION['vendedor'])===0){
                    echo "<p> No hay Personas </p>";
                }else {
                    
                    echo"<div style=overflow-x:auto;>";
                    echo "<table width=100% border=1 cellspacing=0 cellpadding=6>";
                    echo "<table border=1>";
                    echo "<tr>";
                    echo "<th>Nombre Completo</th>";
                    echo "<th>Cantidad Ventas COD</th>";
                    echo "<th>Cantidad Ventas MINECRAFT</th>";
                    echo "<th>Cantidad Ventas FORTNITE</th>";
                    echo "<th>Total Ventas</th>";
                    echo "<th>Comision COD</th>";
                    echo "<th>Comision MINECRAFT</th>";
                    echo "<th>Comision FORTNITE</th>";
                    echo "<th>Comision Total</th>";
                    echo "<th>Imagen del Juego mas Vendido</th>";
                    echo "</tr>";
                    $mayor_c = 0;
                    foreach ($_SESSION['vendedor'] as $key => $value){
                        $cont = ($value['CantCOD']*2070)+($value['CantMIN']*352)+($value['CantFORT']*5238);
                        if ( $cont > $mayor_c ){
                            $mayor_c = $cont;                        
                            $m_c = $value;
                        }
                    }
                                        
        ?>
                    <tr>
                        <td> <b> <?php echo $m_c['Nom']; ?> </td>
                        <td> <b> <?php echo $m_c['CantCOD']; ?> </td>
                        <td> <b> <?php echo $m_c['CantMIN']; ?> </td>
                        <td> <b> <?php echo $m_c['CantFORT']; ?> </td>
                        <!-- total ventas -->
                        <td> <b> <?php echo ($m_c['CantCOD']*34500)+($m_c['CantMIN']*8800)+($m_c['CantFORT']*58200)?> </td>
                        <!--comision COD 2070 -->
                        <td> <b> <?php echo ($m_c['CantCOD']*2070); ?> </td>
                        <!--comision Minecraft 352 -->
                        <td> <b> <?php echo ($m_c['CantMIN']*352); ?> </td>
                        <!--comision Fortnite 5238 -->
                        <td> <b> <?php echo ($m_c['CantFORT']*5238); ?> </td>
                        <!-- total comision -->
                        <td> <b> <?php echo ($m_c['CantCOD']*2070)+($m_c['CantMIN']*352)+($m_c['CantFORT']*5238); ?> </td>
                        <!-- Imagen -->
                        <td> <b> <?php if ($value['CantCOD'] > $value['CantMIN'] && $value['CantCOD'] > $value['CantFORT']) { ?>
                                <img src="img/COD.jpg" id="imgCOD"> <p>Ventas: <?php echo($value['CantCOD']*34500) ?> </p> <?php }elseif($value['CantMIN'] > $value['CantFORT']){ ?>
                                <img src="img/minecraft.jpeg" id="imgMIN"> <p>Ventas: <?php echo($value['CantMIN']*8800) ?> </p> <?php }else{?>
                                <img src="img/fortnite.jpg" id="imgFORT"> <p>Ventas: <?php echo($value['CantFORT']*58200) ?> </p> <?php }?>
                        </td>
                    </tr>
        <?php
                               
                }
                    echo "</table>";
            }
        ?>
        </section>      
    </body>
</html>