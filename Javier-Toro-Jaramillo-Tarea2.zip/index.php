<?php session_start(); ?>
<html>
  <head>
    <title>VENTA DE JUEGOS</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="css/plantilla.css">
  </head>
    
  <body>
        <header>
            <img src="/img/joystick.png" id="logo">
            <h1>TODOS JUEGAN</h1>
        </header>
    <?php
        #Condicion para comprobar si existe un array en la session persona, si esta creada se salta este paso
        if (!isset($_SESSION['persona'])){
            $_SESSION['persona'] = array();   
        }
        
        if (isset($_POST['insertar'])){
            $nom = $_POST['Nom'];
            $vencod = $_POST['Cod'];
            $venmin = $_POST['Min'];
            $venfor = $_POST['For'];
            
            #Condicion para comprobar si las casillas estan completadas al insertar a un vendedor
            if (empty($nom)||empty($vencod)||empty($venmin)||empty($venfor)){
                echo "Rellena todos los campos.";

            #Esta condicion es para saber si el nombre del vendedor solo tiene caracteres alfabeticos.
            }else if(ctype_alpha($nom) == false){
                echo "Solo letras alfa numerica.";
            
            #Esta condicion es para saber si los numeros ingresados son alfa numericos y positivos
            }else if(false == ctype_digit($vencod) || 0 > intval($vencod)||
                     false == ctype_digit($venmin) || 0 > intval($venmin)||
                     false == ctype_digit($venfor) || 0 > intval($venfor)){
                         echo "Solo numeros y que sean positivos.";
            }else{
                #SUMA DEL TOTAL DE VENTAS 
                $totalv = $vencod*34500 + $venmin*8800 + $venfor*58200;
                #CREACION DE LAS COMISIONES DE CADA JUEGO
                $codcom = $vencod*2070;
                $mincom = $venmin*352;
                $forcom = $venfor*5238;
                #SUMA DEL TOTAL DE COMISIONES
                $totalc = $codcom+$mincom+$forcom;
                
                $persona = array(
                    "Nom" => $nom,
                    "Cod" => $vencod,
                    "Min" => $venmin,
                    "For" => $venfor,
                    "ventas" => $totalv,
                    
                    "CodCom" => $codcom,
                    "MinCom" => $mincom,
                    "ForCom" => $forcom,
                    "comision" => $totalc,
                );
                if (isset($_SESSION['persona'][$nom])){
                    echo "Se ha modificado la persona con el nombre: ".$nom;
                }else{
                    echo "Se ha registrado la persona: ";
                }
                $_SESSION['persona'][$nom]=$persona;
                #print_r($_SESSION['persona']);
            }
        }
    ?>
    <form method="post">
        <div id="inputs">
            <br>NOMBRE
            <input type="text" id="Nom" name="Nom">
            <br>VENTAS CALL OF DUTY
            <input type="text" id="Cod" name="Cod">
            <br>VENTAS MINECRAFT
            <input type="text" id="Min" name="Min">
            <br>VENTAS FORTNITE
            <input type="text" id="For" name="For">
            <br>
            <button type="submit" name="insertar"> Insertar </button>
            <button type="submit" name="mostrar"> Mostrar </button>
            <button type="submit" name="vendedor"> Vendedor con mayor comisión </button>
            
            <button type="submit"><a href="main.html">LINK AL CATALOGO</a></button>
        </div>

    <?php
            if(isset($_POST['vendedor'])){
                if (count($_SESSION['persona'])===0){
				    echo "<p> No hay Personas </p>";
			    }else{
                    #Array donde guardare a los que vendieron mas
                    $mayorvendedor = array();
                    #En este foreach recorro y guardo las ventas totales de los vendedores
                    foreach ($_SESSION['persona'] as $key => $value){
                        array_push($mayorvendedor, $value['ventas']);
                    }
                    
                    echo "<table border=1>";
                    echo "<tr>";
                    echo "<th>Nombre Vendedor</th>";
                    echo "<th>Cantidad Ventas COD</th>";
                    echo "<th>Cantidad Ventas MIN</th>";
                    echo "<th>Cantidad Ventas FOR</th>";
                    echo "<th>Total Ventas</th>";
                    echo "<th>Comision Call of Dutty</th>";
                    echo "<th>Comision Minecraft</th>";
                    echo "<th>Comision Fortnite</th>";
                    echo "<th>Comision Total</th>";
                    echo "<th colspan=3>Imagen de los juego</th>";
                    echo "</tr>";
                    foreach ($_SESSION['persona'] as $key => $value){
                        #Con este if comparo a la venta mayor con cada venta, el mayor se muestra en una tabla
                        if (max($mayorvendedor) == $value['ventas']){?>
                            <tr border=>
                            <td> <b> <?php echo $value['Nom']; ?> </td>
                                
                            <td> <b> <?php echo $value['Cod']; ?> </td>
                            <td> <b> <?php echo $value['Min']; ?> </td>
                            <td> <b> <?php echo $value['For']; ?> </td>
                            <td> <b> <?php echo $value['ventas']; ?> </td>
                                
                            <td> <b> <?php echo $value['CodCom']; ?> </td>
                            <td> <b> <?php echo $value['MinCom']; ?> </td>
                            <td> <b> <?php echo $value['ForCom']; ?> </td>
                            <td> <b> <?php echo $value['comision']; ?> </td>
                            <td>
                                <img src="/img/cod.jpg" id="imgCod">
                                <p>Precio = $34500
                                <p> <?php echo "Total ventas = $",$value['Cod']*34500; ?> </p>
                                <p> <?php echo "Total comisión= $",$value['comision']; ?> </p>
                            </td>
                            <td>
                                <img src="/img/minecraft.jpg" id="imgMine">
                                <p>Precio = $8800
                                <p> <?php echo "Total ventas = $",$value['Min']*8800; ?> </p>
                                <p> <?php echo "Total comisión= $",$value['comision']; ?> </p>
                            </td>
                            <td>
                                <img src="/img/fortniteventa.jpg" id="imgFort">
                                <p>Precio = $58200
                                <p> <?php echo "Total ventas = $",$value['For']*58200; ?> </p>
                                <p> <?php echo "Total comisión= $",$value['comision']; ?> </p>
                            </td>
                            </tr>
    <?php  
            
    echo "</table>";
                        }
                    }
                }
            }
    ?>
    <?php
        
        if (isset($_POST['mostrar'])){
			if (count($_SESSION['persona'])===0){
				echo "<p> No hay Personas </p>";
			}else {
            echo "<table border=1>";
            echo "<tr>";
            echo "<th>Nombre Vendedor</th>";
            echo "<th>Cantidad Ventas COD</th>";
            echo "<th>Cantidad Ventas MIN</th>";
            echo "<th>Cantidad Ventas FOR</th>";
            echo "<th>Total Ventas</th>";
            echo "<th>Comision Call of Dutty</th>";
            echo "<th>Comision Minecraft</th>";
            echo "<th>Comision Fortnite</th>";
            echo "<th>Comision Total</th>";
            echo "<th colspan=3>Imagen de los juego</th>";
            echo "</tr>";
            foreach ($_SESSION['persona'] as $key => $value){
    ?>  
        <tr>
        <!--<td><input type="checkbox" name="noms[]" value= "<?php echo $key; ?>"></td> -->
        <td> <?php echo $value['Nom']; ?> </td>
            
        <td> <?php echo $value['Cod']; ?> </td>
        <td> <?php echo $value['Min']; ?> </td>
        <td> <?php echo $value['For']; ?> </td>
        <td> <?php echo $value['ventas']; ?> </td>
            
        <td> <?php echo $value['CodCom']; ?> </td>
        <td> <?php echo $value['MinCom']; ?> </td>
        <td> <?php echo $value['ForCom']; ?> </td>
        <td> <?php echo $value['comision']; ?> </td>
        <td>
            <img src="/img/cod.jpg" id="imgCod" >
            <p>Precio = $34500
            <p> <?php echo "Total ventas = $",$value['Cod']*34500; ?> </p>
            <p> <?php echo "Total comisión= $",$value['comision']; ?> </p>
        </td>
        <td>
            <img src="/img/minecraft.jpg" id="imgMine">
            <p>Precio = $8800
            <p> <?php echo "Total ventas = $",$value['Min']*8800; ?> </p>
            <p> <?php echo "Total comisión= $",$value['comision']; ?> </p>
        </td>
        <td>
            <img src="/img/fortniteventa.jpg" id="imgFort">
            <p>Precio = $58200
            <p> <?php echo "Total ventas = $",$value['For']*58200; ?> </p>
            <p> <?php echo "Total comisión= $",$value['comision']; ?> </p>
        </td>
        </tr>
    <?php  
            }
    echo "</table>";
            }    
        }
    ?>
    
    </body>
</html>