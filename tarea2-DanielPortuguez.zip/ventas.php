<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ZMART</title>
    <link rel="shortcut icon" href="img/icono.ico" type="image/x-icon">
    <link rel="stylesheet" href="estilos.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <header>
        <nav>
            <input type="checkbox" id="ckbox">
            <label for="ckbox" class="drawer">
            <i class="fa fa-bars" aria-hidden="true"></i>
            </label>
            <a href="index.html"> <img src="img/logo zmart.png"  alt=""/></a>
            <h1></h1>
            <ul class="menu-box">
                <li><a href="index.html" class="fa fa-home"><p> Inicio</p></a></li>
                <li><a href="ventas.php" class="fa fa-shopping-bag"><p>Compras</p></a></li>
            </ul>
        </nav>
    </header>
    <h1>Compras</h1>

    <!--PHP -->
<?php 
		
		if (!isset($_SESSION['persona'])){
			$_SESSION['persona']= array();
		}

		
		if (isset($_POST['insertar'])){

		
			$rut = $_POST['RUT'];
			$nom = $_POST['NOM'];
			$ape = $_POST['APE'];
			$callofdutyc = $_POST['CALLC'];
			$minecraftc = $_POST['MINEC'];
			$fornitec = $_POST['FORNC'];

		
			if (empty($rut)||empty($nom)||empty($ape)||empty($callofdutyc)||empty($minecraftc)||empty($fornitec)){
				echo "Rellena todos los valores";

			} else if (!ctype_alpha($nom) || !ctype_alpha($ape)){
				echo "Solo se admiten letras en los campos nombre y apellido";

			} else if (!ctype_digit($callofdutyc) || !ctype_digit($minecraftc) || !ctype_digit($fornitec)){
				echo "Solo se pueden colocar numeros en las cantidades de juegos vendidos";

			} else {

		
				$totalventas = 0.06*34500*(intval($callofdutyc))+0.04*8800*(intval($minecraftc))+0.09*58200*(intval($fornitec));

				$persona = array(
					"rut" => $rut,
					"Nombre" => $nom,
					"Apellido" => $ape,
					"callofdutycantidad" => intval($callofdutyc),
					"minecraftcantidad" => intval($minecraftc),
					"fornitecantidad" => intval($fornitec),
					"totalvent" => intval($callofdutyc)+intval($minecraftc)+intval($fornitec),
					"callofdutycom" => "6%",
					"minecraftcom" => "4%",
					"fornitecom" => "5%",
					"comisionTotal" => $totalventas,
				); 

				
				if (isset($_SESSION['persona'][$rut])){
					echo "Se ha modificado la Persona con el RUT: ".$rut;
			
				}else{
					echo "Se ha registrado la persona";
				}		

	
				$_SESSION['persona'][$rut]=$persona;
				
      }
    }else if (isset($_POST['vaciar'])){
  			if (!isset($_POST['ruts'])){
  				echo "No hay Personas seleccionadas";
  
  			}else{	
  				$ruts=$_POST['ruts'];
  				print_r($ruts);
  
  				foreach ($_SESSION['persona'] as $key =>$value){
  					if (in_array($key,$ruts)){
  						unset($_SESSION['persona'][$key]);
  					}
				}
			echo "Persona(s) Borradas";
			}
		}
	?>

	
	<form method="post">
		<caption><h2>Datos Del vendedor</h2></caption>
		<label for="RUT"><h3>Rut Vendedor</h3></label>
		<center><input type="text" id="RUT" name="RUT" /></center>
		<br>
		<label for="NOM"><h3>Nombre Vendedor</h3></label>
		<center><input type="text" id="NOM" name="NOM" /></center>
		<br>
		<label for="RUT"><h3>Apellido Vendedor</h3></label>
		<center><input type="text" id="APE" name="APE" /></center>
		<br>
		<label for="RUT"><h3>Cantidad ventas COD</h3></label>
		<center><input type="text" id="CALLC" name="CALLC" /></center>
		<br>
		<label for="RUT"><h3>Cantidad ventas Minecraft</h3></label>
		<center><input type="text" id="MINEC" name="MINEC" /></center>
		<br>
		<label for="RUT"><h3>Cantidad ventas Fornite</h3></label>
		<center><input type="text" id="FORNC" name="FORNC" /></center>
		<br>
		<center><button type="submit" name="insertar">Insertar</button>
		<button type="submit" name="mostrar">Mostrar</button>
		<button type="submit" name="vendedores">Vendedores</button>
		<button type="submit" name="vaciar">Vaciar</button></center>
	
	
	<?php
		// esta seccion es para el boton mostrar
		if (isset($_POST['mostrar'])){
			if (count($_SESSION['persona'])===0){
				echo "<p> No hay Personas </p>";
			}else {
				echo "<table border=2>";
				echo "<tr>";
				echo "<th></th>";
				echo "<th><p>Rut Vendedor</p></th>";
				echo "<th><p>Nombre Vendedor</p></th>";
				echo "<th><p>Apellido Vendedor</p></th>";
				echo "<th><p>Cantidad ventas COD</p></th>";
				echo "<th><p>Cantidad ventas Minecraft</p></th>";
				echo "<th><p>Cantidad ventas Fornite</p></th>";
				echo "<th><p>Total</p></th>";
				echo "<th><p>Comisión Call of Duty</p></th>";
				echo "<th><p>Comisión Minecraft</p></th>";
				echo "<th><p>Comisión Fornite</p></th>";
				echo "<th><p>COMISIÓN TOTAL</p></th>";
				echo "<tr>";

				foreach ($_SESSION['persona'] as $key => $value){
					?>
					<tr>
						<td><input type="checkbox" name="ruts[]" value="<?php echo $key; ?>"> </td>
						<td><p><?php echo $value['rut']; ?></p></td>
						<td><p><?php echo $value['Nombre']; ?></p></td>
						<td><p><?php echo $value['Apellido']; ?></p></td>
						<td><p><?php echo $value['callofdutycantidad']; ?></p></td>
						<td><p><?php echo $value['minecraftcantidad']; ?></p></td>
						<td><p><?php echo $value['fornitecantidad']; ?></p></td>
						<td><p><?php echo $value['totalvent']; ?></p></td>
						<td><p><?php echo $value['callofdutycom']; ?></p></td>
						<td><p><?php echo $value['minecraftcom']; ?></p></td>
						<td><p><?php echo $value['fornitecom']; ?></p></td>
						<td><p><?php echo $value['comisionTotal']; ?></p></td>
					</tr>
					<?php 
				}
				echo "</table>";
			} 
		}

// esta seccion es para el boton vendedores
		if (isset($_POST['vendedores'])){
			if (count($_SESSION['persona'])===0){
				echo "<p> No hay Personas </p>";
			}else {
				echo "<table>";
				echo "<tr>";
				echo "<th></th>";
				echo "<th><p>Rut Vendedor</p></th>";
				echo "<th><p>Nombre Vendedor</p></th>";
				echo "<th><p>Apellido Vendedor</p></th>";

				echo "<tr>";

				foreach ($_SESSION['persona'] as $key => $value){
					?>
					<tr>
						<td><input type="checkbox" name="ruts[]" value="<?php echo $key; ?>"> </td>
						<td><p><?php echo $value['rut']; ?></p></td>
						<td><p><?php echo $value['Nombre']; ?></p></td>
						<td><p><?php echo $value['Apellido']; ?></p></td>
					</tr>
					<?php 
				}
				echo "</table>";
        
			} 
		}

	?>
	</form>

    <footer>
        <p>Contacto</p>
        <navfoot>
            <ul class="footer-box">
                <li><a href="https://www.facebook.com/zmart.cl" class="fa fa-facebook"></a></li>
                <li><a href="https://www.instagram.com/zmart.cl/?hl=es-la" class="fa fa-instagram"></a></li>
            </ul>
        </navfoot>
    </footer>
</body>
</html>